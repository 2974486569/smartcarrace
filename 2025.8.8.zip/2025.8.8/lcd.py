from machine import *
from array import *
from display import *
import gc
import time
import ccd
import ccd_class
import key


# 屏幕引脚初始化
cs = Pin('B29' , Pin.OUT, value=True)
cs.high()
cs.low()
rst = Pin('B31', Pin.OUT, value=True)
dc  = Pin('B5' , Pin.OUT, value=True)
blk = Pin('C21', Pin.OUT, value=True)

# 屏幕配置初始化
drv = LCD_Drv(SPI_INDEX=2, BAUDRATE=60000000, DC_PIN=dc, RST_PIN=rst, LCD_TYPE=LCD_Drv.LCD200_TYPE)
lcd = LCD(drv)
lcd.color(0xFFFF, 0x0000)
lcd.mode(4)
lcd.clear()

#菜单类初始化
param_page = 0    #页数
param_change = 0  #增减标志位
param_select = 0  #选择标号


p0param_list = []   #对象列表
p1param_list = []   #对象列表
p2param_list = []   #对象列表
p3param_list = []   #对象列表
p4param_list = []   #对象列表

#第0页
param_list = [p0param_list,p1param_list,p2param_list,p3param_list,p4param_list]   #对象列表
param_num = [0] * 5     #对象总数


ccd_select = [0]

#参数类
class DATA:
    def __init__(self,name,value,step,page):
        global param_list

        self.index = param_num
        self.name = name
        self.value = value
        self.step = step
        self.page = page
        
        param_list[page].append(self)

    def set(self,name,value,step = 0):
        global param_num

        self.name = name
        self.value = value
        self.step = step
        
        param_num[self.page] += 1
        
        
    def add(self):
        if self.step != 0:
            self.value[0] += self.step
    def sub(self):
        if self.step != 0:
            self.value[0] -= self.step
            




p0data1 = DATA("empty",0,0,0)
p0data2 = DATA("empty",0,0,0)
p0data3 = DATA("empty",0,0,0)
p0data4 = DATA("empty",0,0,0)
p0data5 = DATA("empty",0,0,0)
p0data6 = DATA("empty",0,0,0)
p0data7 = DATA("empty",0,0,0)
p0data8 = DATA("empty",0,0,0)
p0data9 = DATA("empty",0,0,0)
p0data10 = DATA("empty",0,0,0)

p1data1 = DATA("empty",0,0,1)
p1data2 = DATA("empty",0,0,1)
p1data3 = DATA("empty",0,0,1)
p1data4 = DATA("empty",0,0,1)
p1data5 = DATA("empty",0,0,1)
p1data6 = DATA("empty",0,0,1)
p1data7 = DATA("empty",0,0,1)
p1data8 = DATA("empty",0,0,1)
p1data9 = DATA("empty",0,0,1)


p2data1 = DATA("empty",0,0,2)
p2data2 = DATA("empty",0,0,2)
p2data3 = DATA("empty",0,0,2)
p2data4 = DATA("empty",0,0,2)
p2data5 = DATA("empty",0,0,2)
p2data6 = DATA("empty",0,0,2)
p2data7 = DATA("empty",0,0,2)
p2data8 = DATA("empty",0,0,2)
p2data9 = DATA("empty",0,0,2)
p2data10 = DATA("empty",0,0,2)

p3data1 = DATA("empty",0,0,3)
p3data2 = DATA("empty",0,0,3)
p3data3 = DATA("empty",0,0,3)
p3data4 = DATA("empty",0,0,3)
p3data5 = DATA("empty",0,0,3)
p3data6 = DATA("empty",0,0,3)
p3data7 = DATA("empty",0,0,3)
p3data8 = DATA("empty",0,0,3)
p3data9 = DATA("empty",0,0,3)
p3data10 = DATA("empty",0,0,3)

p4data1 = DATA("empty",0,0,4)
p4data2 = DATA("empty",0,0,4)
p4data3 = DATA("empty",0,0,4)
p4data4 = DATA("empty",0,0,4)
p4data5 = DATA("empty",0,0,4)
p4data6 = DATA("empty",0,0,4)
p4data7 = DATA("empty",0,0,4)
p4data8 = DATA("empty",0,0,4)
p4data9 = DATA("empty",0,0,4)
p4data10 = DATA("empty",0,0,4)
#将摄像头图像显示到屏幕上
def show_ccd():
    
    global ccd_select
    if ccd_select[0] == 0:
        pass
        lcdmax = ccd.ccd_data1[ccd.c1.boundary_left[0]-2] / (ccd.c1.max[0]+1)
        lcdmin = ccd.ccd_data1[ccd.c1.boundary_left[0]+2] / (ccd.c1.max[0]+1)
        lcdmid = (lcdmax + lcdmin)/2

          
    
        lcd.wave(0, 219, 128, 100, ccd.ccd_data1, max = ccd.c1.max[0])
        lcdy = ccd.c1.threshold[0] / (ccd.c1.max[0]+1)
        lcd.line(  64, 319-int(lcdy * 100), 128, 319-int(lcdy * 100), color = 0xFFFF, thick = 1)
        lcd.line(  0, 219, 128, 219, color = 0xFFFF, thick = 1)
        lcd.line(  0, 319-int(lcdmid * 100), 63, 319-int(lcdmid * 100), color = 0xf800, thick = 1)
        lcd.line(  0, 319-int(lcdmax * 100), 63, 319-int(lcdmax * 100), color = 0x00F5, thick = 1)
        lcd.line(  0, 319-int(lcdmin * 100), 63, 319-int(lcdmin * 100), color = 0x00F5, thick = 1)
        
    elif ccd_select[0] == 1:
        pass
        lcd.wave(0, 219, 128, 100, ccd.ccd_data2, max = ccd.c2.max[0])
        lcdy = ccd.c2.threshold[0] / (ccd.c2.max[0]+1)
        lcd.line(  64, 319-int(lcdy * 100), 128, 319-int(lcdy * 100), color = 0xFFFF, thick = 1)
        lcd.line(  0, 219, 128, 219, color = 0xFFFF, thick = 1)

#菜单显示函数，不能放中断里，只能放while循环里
def show():
    global param_num,param_select,param_change
    global param_page
    global p1param_num,p2param_num
    global p_1param_num,p_2param_num
    key.get()
    
    #按键判断
    if key.data[0] != 0:  #选择
        param_select -= 1
        key.data[0] = 0
    if key.data[1] != 0:
        param_select += 1
        key.data[1] = 0
        
        
    if key.data[2] != 0:# 加减
        param_change = 1
        key.data[2] = 0
    if key.data[3] != 0:
        param_change = 2
        key.data[3] = 0


    if key.data5[0] != 0:# 翻页
        param_page = 3 
        lcd.clear()
        key.data5[0] = 0
    if key.data6[0] != 0:# 翻页
        param_page = 0 
        lcd.clear()
        key.data6[0] = 0
    if key.data7[0] != 0:# 翻页
        param_page = 1
        lcd.clear()
        key.data7[0] = 0
    if key.data8[0] != 0:# 翻页
        param_page = 2
        lcd.clear()
        key.data8[0] = 0
        
    #param_page += 1
    #lcd.clear()
        
    #页数限幅
    if(param_page >= 5): 
        param_page = 0
    elif(param_page <= -1): 
        param_page = 4 
        
    #标号限幅
    if param_select < 0:
        param_select = param_num[param_page]-1
    if param_select >= param_num[param_page]:
        param_select = 0

    
    lcd.str32(220, 0 * 32, "{:.0f}".format(param_page), 0x07E0)        
    #第0页     #屏幕显示
    for i in range(0,param_num[param_page]):
        if((param_list[param_page])[i].name == "empty"):
                pass
        else:
            if(i == param_select):
            
                lcd.str32(0, i * 32, ((param_list[param_page])[i].name), 0xf800)
                lcd.str32(116, i * 32, "{:.2f}".format((param_list[param_page])[i].value[0]), 0xf800)
            
                if(param_change == 1):   #增加
                    (param_list[param_page])[i].add()
                    param_change = 0
                    
                elif(param_change == 2): #减少
                    (param_list[param_page])[i].sub()
                    param_change = 0
            else:
                lcd.str32(0, i * 32, ((param_list[param_page])[i].name), 0xFFFF)
                lcd.str32(116, i * 32, "{:.2f}".format((param_list[param_page])[i].value[0]), 0xFFFF)
