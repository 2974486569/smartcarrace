#摄像头初始化，图像处理
#
#
#
#
#版本V1.0
#温昊4.19

#导入所需库
from machine import *
from smartcar import ticker
from display import *
from seekfree import TSL1401
from seekfree import DL1X
import gc
import time
import ccd
import pid
import ccd_class as cs
import ccd_control

#摄像头初始化
ccd = TSL1401(1)
ccd.set_resolution(TSL1401.RES_12BIT)
ccd1 = ccd.get(3)
ccd2 = ccd.get(2)


ccd_data1 = [0] * 128
ccd_data2 = [0] * 128

ccd_data_x = [0] * 128


ccd_start  = 1
check = [1]




class CCD:
    def __init__(self,threshold_rate):
        self.min = [0]                           #图像亮度最小值
        self.max = [0]                           #图像亮度最大值
        self.threshold = [0]                     #二值化阈值
        self.threshold_black = [0]                #最低阈值
        self.threshold_rate = threshold_rate   #动态阈值的比例
        self.bin_data = [0] * 128              #二值化后的图像数据
        self.boundary_left = [0]                 #图像左边界
        
        self.boundary_left_last = [0]            #图像上一次左边界
        self.boundary_right = [0]                #图像右边界
        self.boundary_right_last = [0]           #图像上一次右边界
        self.boundary_middle = [0]               #图像中心
        self.boundary_middle_last = [0]          #图像上一次中心
        self.boundary_middle_last2 = [0]         #图像上上一次中心
        self.width = [0]                         #赛道宽度
        self.width_last = [0]                    #上一次赛道宽度
        self.set_width = [0]                     #赛道宽度常数
        self.error = [0]                         #图像中心与赛道中线的偏差值
        self.image_middle = [63.5]                  #赛道中线
        self.cross_or_circle = [0]               #分辨圆环和十字的标志位
        
        self.max_global = [0]
        
        self.max_limit = [60000]
    
    
c1_threshold = [0.45]
c2_threshold = [0.33]
c1 = CCD(c1_threshold)
c2 = CCD(c2_threshold)
start_point = [5,-5,10,-10,15,-15,20,-20,25,-25,30,-30,35,-35]



#取绝对值
def ccd_abs(num):
    if num < 0:
        return -num
    else:
        return num



#摄像头图像二值化
def ccd_binarization(): 
    
    global ccd_data1,ccd_data2
    
#——————————————————————————————————————————————————————————————————————————————————————————————-CCD1
    ccd_max = 0
    ccd_min = ccd_data1[0]

    for i in range(0,128):                        #寻找最大值与最小值
         #找最大值
        if(ccd_data1[i] > ccd_max):
            ccd_max = ccd_data1[i]

        #找最小值
        if(ccd_data1[i] < ccd_min):
            ccd_min = ccd_data1[i]

    c1.max[0] = ccd_max
    c1.min[0] = ccd_min

    threshold1 = ccd_min + c1.threshold_rate[0] * (ccd_max - ccd_min)       #ccd1的找动态阈值
    c1.threshold[0] = threshold1
        
        
    #if(threshold1 < c1.threshold_black *0.5):     #防止阈值过低
        #threshold1 = c1.threshold_black

    #c1.max[0] - c1.min[0] > c1.min[0] * 1.2   
    #if(c1.max[0] - c1.min[0] > c1.min[0] * cs.out.threshold[0]): #如果图像最大值与最小值相差有一定数值，则进行二值化
    if(True):
        for i in range(0,128):
            if(ccd_data1[i] > threshold1):       
                c1.bin_data[i] = 1
            else:
                c1.bin_data[i] = 0
    else:                                         #如果图像最大值与最小值相差极小,则不处理
        for i in range(0,128):
            c1.bin_data[i] = 0
            
#——————————————————————————————————————————————————————————————————————————————————————————————-CCD2

    ccd_max = 0
    ccd_min = ccd_data2[0]

    for i in range(0,128):                        #寻找最大值与最小值
         #找最大值
        if(ccd_data2[i] > ccd_max):
            ccd_max = ccd_data2[i]

        #找最小值
        if(ccd_data2[i] < ccd_min):
            ccd_min = ccd_data2[i]

    c2.max[0] = ccd_max
    c2.min[0] = ccd_min

    threshold2 = ccd_min + c2.threshold_rate[0] * (ccd_max - ccd_min)       #ccd1的找动态阈值
    c2.threshold[0] = threshold2
        
        
    #if(threshold2 < c2.threshold_black *0.5):     #防止阈值过低
        #threshold2 = c2.threshold_black

    #c2.max[0] - c2.min[0] > c2.min[0] * 1.2
    #if(c2.max[0] - c2.min[0] > c2.min[0] * cs.out.threshold[0]):#如果图像最大值与最小值相差有一定数值，则进行二值化
    if(True):
        for i in range(0,128):
            if(ccd_data2[i] > threshold2):       
                c2.bin_data[i] = 1
            else:
                c2.bin_data[i] = 0
    else:                                         #如果图像最大值与最小值相差极小,则不处理
        for i in range(0,128):
            c2.bin_data[i] = 0
            

        

#摄像头寻找赛道左右边界
def ccd_boundary(ccd):
    
    
    ccd.boundary_right_last[0] = ccd.boundary_right[0]        #中线迭代
    ccd.boundary_left_last[0] = ccd.boundary_left[0]          #中线迭代
    
    ccd.boundary_left[0] = 4
    ccd.boundary_right[0] = 123
    
    y =  64 #ccd.boundary_middle_last
    
    if(ccd.bin_data[y] != 1):        
        for i in range(0,14):             #寻找合适的起始点开始寻找边界
            if(ccd.bin_data[y + start_point[i]] != 0):
                y = y + start_point[i]
                break

    
    for i in range(y,123):                     #从边界右扫描
        if(ccd.bin_data[i] == 0):
            if(ccd.bin_data[i+1] == 0 and ccd.bin_data[i+2] == 0 and ccd.bin_data[i+3] == 0):
                ccd.boundary_right[0] = i
                break

    for i in range(y,4,-1):                        #从边界左扫描
        if(ccd.bin_data[i] == 0):
            if(ccd.bin_data[i-1] == 0 and ccd.bin_data[i-2] == 0 and ccd.bin_data[i-3] == 0):
                ccd.boundary_left[0] = i
                break
            
    
    ccd.width_last[0] = ccd.width[0]                                  #宽度迭代
    
    ccd.width[0] = ccd.boundary_right[0] - ccd.boundary_left[0]          #扫描赛道宽度
    
    ccd.boundary_middle_last2[0] = ccd.boundary_middle_last[0]        #中线迭代

    ccd.boundary_middle_last[0] = ccd.boundary_middle[0]              #中线迭代
    
    ccd.boundary_middle[0] = (ccd.boundary_left[0] + ccd.boundary_right[0]) / 2 #寻找中线
    
    ccd.cross_or_circle[0]  = ccd_abs(ccd_abs(ccd.boundary_left[0] - ccd.image_middle[0])-ccd_abs(ccd.boundary_right[0] - ccd.image_middle[0]))
    
    ccd.error[0] = -(ccd.image_middle[0] - ccd.boundary_middle[0])        #寻找偏差
    
    if(ccd_abs(ccd.error[0]) <= 1):                                 #误差值小于2不处理 
        ccd.error[0] = 0
        
    

def ccd_data_x_change():  # 手动拉平图像
    global ccd_data_x
    
    sb = 0
    for i in range(0,128):
        if(i<54 or i>74):
            sb = ccd_abs(i-64)  #20
        else:
            sb = 64-54      #10
            
        ccd_data_x[i] = ccd_abs(1 + sb/64*0.3)
            

        
def ccd_gamma():   # 对图像进行伽马校正
    global ccd_data1, ccd_data2, ccd_data_x, ccd1, ccd2, c1, c2

    
    ccd_data1 = ccd1[:]
    ccd_data2 = ccd2[:]
    for i in range(0,128):
        
        ccd_data1[i] = ccd_abs(int(ccd1[i]/10 * ccd1[i]/10 * ccd_data_x[i]))
        ccd_data2[i] = ccd_abs(int(ccd2[i]/10 * ccd2[i]/10 * ccd_data_x[i]))
        if ccd_data1[i] > c1.max_limit[0]:
            ccd_data1[i] = c1.max_limit[0]
        if ccd_data2[i] > c2.max_limit[0]:
            ccd_data2[i] = c2.max_limit[0]
            
        if ccd_data1[i] < 0 :
            ccd_data1[i] = 0
        if ccd_data2[i] < 0:
            ccd_data2[i] = 0
     


#摄像头处理总进程    
def process():
    global c1,c2,ccd_start,check
    if ccd_start == 1:
        ccd_data_x_change()
        ccd_start = 0
    
    ccd_gamma()
    ccd_binarization()
    ccd_boundary(c1)
    ccd_boundary(c2)

    if(check[0] == 1):
        ccd_control.check()
    ccd_control.strategy()
        
    

        

