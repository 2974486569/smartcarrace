#陀螺仪获取对应角度与角速度
#
#在中断里通过imu.data.get()获取陀螺仪数据
#角度值读取imu.data.roll    角速度值读取imu.data.gx
#
#版本V1.0
#温昊4.17



#导入所需库
from seekfree import IMU660RX
from smartcar import ticker
import math
import pid
import uart
#创建陀螺仪对象data
class DATA:
    
    #对象初始化
    def __init__(self):
        
        #原始值
        self.ay = 0
        self.az = 0
        self.gx = 0
        self.gy = 0
        self.gz = 0
        self.ay_last = 0
        self.az_last = 0
        self.gx_last = 0
        self.gz_last = 0
        
        self.mygy = 0
        self.mygz = 0
        
        #一阶互补滤波参数
        self.filter = 0.3
        
        #X轴角度
        self.roll = 0
        self.roll_temp = 0
        self.roll_acc = 0
        self.roll_gypo = 0
        
        
        #Z轴角度
        self.yaw = 0
        
        
        
        self.temp_angle = 0   
        self.angle = 0            #数据融合后的角度    
#         self.acc_ratio = 2.66    #加速度计比例    
#         self.gyro_ratio = 2.66   #陀螺仪比例
        self.acc_ratio = 1.25     #加速度计比例    
        self.gyro_ratio = 2.55    #陀螺仪比例 
        self.dt = 0.01    
        self.last_angle = 0
        self.first_angle = 0
        
        
    #陀螺仪解算函数，获取对应角度 
    def get(self):
        global imu_data
        self.ay = imu_data[1]
        self.az = imu_data[2]
        self.gx = imu_data[3]
        self.gz = imu_data[5]
        
        #self.gx = self.filter * self.gx + (1-self.filter)  * self.gx_last
        #self.gx_last = self.gx
        #陀螺仪0偏校准
        #self.gx -= 3.1
        #if self.gx < 3.5 and self.gx > -3.5:
        #    self.gx = 0
        

        #self.self.gz += 0
        #if(self.gz  0.6 and self.gz  -0.6)
        #self.gz = 0

        #self.ay = self.filter * self.ay + (1-self.filter) * self.ay_last
        #self.ay_last = self.ay

        #self.az = self.filter * self.az + (1-self.filter) * self.az_last
        #self.az_last = self.az
        
        
    
        self.roll_acc = math.atan(self.ay/self.az) / math.pi * 180
        self.roll_gypo = self.roll_temp + 0.01 * self.gx
        self.roll_temp = (self.roll_acc * (1-self.filter) +  self.roll_gypo * (self.filter))
        self.roll = self.roll_temp / 180 * 3.14
        
        self.gz = self.gz - self.gx * math.sin(self.roll)
        #self.roll = self.roll +17.9
        
        #uart.send(0, self.roll, self.gx)
        
        
        
    #----------------------------------------------------------------    

    #  @brief      一阶互补滤波    

    #  @param      angle_m     加速度计数据    

    #  @param      gyro_m      陀螺仪数据    

    #  @return     float       数据融合后的角度    

    #----------------------------------------------------------------    

    def angle_calc(self):
        global imu_data
        self.ay = imu_data[1]
        self.az = imu_data[2]
        self.gx = imu_data[3]
        self.gy = imu_data[4]
        self.gz = imu_data[5]
        
        
        self.roll_acc = math.atan(self.ay/(self.az+1)) / math.pi * 180
        self.roll_gypo = self.roll_temp + 0.01 * self.gx
        self.roll_temp = (self.roll_acc * (1-self.filter) +  self.roll_gypo * (self.filter))
        self.roll = self.roll_temp / 180 * 3.14 
        
        self.mygy = self.gy * 0.07
        self.mygz = self.gz * 0.07
        self.mygz = self.mygz + self.mygy * math.sin(self.roll)
        
#         self.acc_ratio = pid.acc_ratio[0]
#         self.gyro_ratio = pid.gyro_ratio[0]
        
                  
        gyro_now = 0    
        error_angle = 0    
        if not self.first_angle:#判断是否为第一次运行本函数    
            #如果是第一次运行，则将上次角度值设置为与加速度值一致    
            self.first_angle = 1    
            self.last_angle = self.az
        
        gyro_now = self.gx * self.gyro_ratio
        
        #根据测量到的加速度值转换为角度之后与上次的角度值求偏差    
        error_angle = (self.az - self.last_angle)*self.acc_ratio 

        #根据偏差与陀螺仪测量得到的角度值计算当前角度值    
        self.temp_angle = self.last_angle + (error_angle + gyro_now)*self.dt   

        #保存当前角度值    
        self.last_angle = self.temp_angle  
#         uart.send(0, self.temp_angle, self.gx, self.az)
        
        self.yaw += 0.01 * self.mygz
  

      




        
#陀螺仪初始化
imu = IMU660RX()
#imu.help()
#imu.info()
imu_data = imu.get()
data = DATA()
