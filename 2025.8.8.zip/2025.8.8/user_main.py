# 从 machine 库包含所有内容
from machine import *

# 包含 gc 与 time 类
import gc
import time
import imu
import lcd
import pid
import ccd_class as cs 
import ccd

import uart
import ccd_strategy as cd



from smartcar import ticker
from seekfree import MOTOR_CONTROLLER
# 核心板上 C4 是 LED
# 学习板上 D9  对应二号拨码开关

switch2 = Pin('D9' , Pin.IN , pull = Pin.PULL_UP_47K)
state2  = switch2.value()








pid.pid_contral_ticker()

while True:
    #time.sleep_ms(500)
    #led.toggle()
    #print("led ={:>6d}".format(led.value()))
    
    #uart.send_ccd(1)
    #ccd.ccd_gamma()
    #cd.box()
    
    
    #cd.circle1()
    #cd.circle()
    #uart.send(imu.data.gz)
    #cd.circle()keyi
    #cd.cross3

            

#     
    #if(pid.start[0] != 2 and pid.start[0] != -1):
    if(pid.start[0] < 10):
        lcd.show()
    if(lcd.param_page == 1):
        lcd.show_ccd()
    if(pid.start[0] == 2):
        pass
        #uart.send(imu.data.temp_angle,ccd.c1.width[0])
    
        #uart.send((pid.enc1_data+pid.enc2_data)/2)
        #
        #uart.send(cs.circle.num[0], cs.circle.out_angle[0], cs.circle.out_enc1[0])


    #print(333)
        
    #uart.send(0, imu.data.gx, imu.data.roll)
    # 如果拨码开关打开 对应引脚拉低 就退出循环
    # 这么做是为了防止写错代码导致异常 有一个退出的手段
    if switch2.value() != state2:
        print("Test program stop.")
        break
    gc.collect()
