from seekfree import MOTOR_CONTROLLER
from smartcar import ticker
from smartcar import encoder
import imu
import uart
import lcd
import ccd
import ccd_check
import ccd_class
import math
import my_speed
import key


motor_2 = MOTOR_CONTROLLER(MOTOR_CONTROLLER.PWM_C30_DIR_C31, 13000, duty = 0, invert = True)  #正
motor_1 = MOTOR_CONTROLLER(MOTOR_CONTROLLER.PWM_C28_DIR_C29, 13000, duty = 0, invert = True) #正
encoder_2 = encoder("D13", "D14")        #you
encoder_1 = encoder("D15", "D16", True)  #zuo
start = [0]
start_last = [0]

imu_count=0
angle_count=0
gyro_count=0
speed_count=0
art_count=0
art_wait=1

speed_tim  = 0#保护

out = 0
angle_out = 0
speed_out = 0
limit_jia = 0  #速度环加速限幅
limit_jian = 0 #速度环减速速限幅
#enc_flag
enc1_data = 0
enc2_data = 0

enc_sum_judge = [0]
ensum = [0]

e1 = [0]
e2 = [0]

#Kpg = [-5.5]
Kpg = [-4.2]
Kdg = [-0.1]
Kpa = [5.5]
Kda = [0.125]
# 
# Kps = [-4.5]
Kps = [-5]
Kis = [-0]
Kds = [0]
speed = -60
target_speed = [-150]

enc_protect = [1000]

my_last = [0]
#SLOW_down

kp = [80]
kp2= [1.4]
kd = [0]
kd2= [0.5]

# #-220速度的参数，不稳定
# 
# target_speed = [-250]
# kp = [110]
# kp2= [1]
# kd = [0]
# kd2= [0.385]
# 
# Kpg = [-4.37]
# Kdg = [-0.1]
# 
# Kpa = [4.8]
# Kda = [0.125]
# 
# Kps = [-5]
# Kis = [-0]
# 
turn_out = 0
error = [0]
width = [0]
angle = [0]
mgz = [0]
aaa = [0]
imu_0 = [4030]
# imu_0 = [4055]
# acc_ratio = [1.25]
# gyro_ratio = [2.55]


gx_filter = 0


# 调参用的菜单
lcd.p0data1.set("start", start, 1)
lcd.p0data2.set("rank", my_speed.rank, 1)
lcd.p0data3.set("Kpg", Kpg, 0.01)
lcd.p0data4.set("Kpa", Kpa, 0.01)
lcd.p0data5.set("kps",  Kps, 0.1)
lcd.p0data6.set("kp2",  kp2, 0.01)
lcd.p0data7.set("kp2",  kp2, 0.1)
lcd.p0data8.set("kp",  kp, 2)
lcd.p0data9.set("kd2",  kd2, 0.02)
lcd.p0data10.set("angle",  angle, 10)
# #lcd.p0data9.set("acc_ratio",  acc_ratio, 0.01)
# #lcd.p0data10.set("gyro_ratio",  gyro_ratio, 0.01)

# lcd.p0data1.set("start", start, 1)
# lcd.p0data2.set("rank", my_speed.rank, 1)
# lcd.p0data3.set("Kpg", my_speed.kpg, 0.01)
# lcd.p0data4.set("Kpa",  my_speed.kpa, 0.01)
# lcd.p0data5.set("kps",  my_speed.kps, 0.1)
# lcd.p0data6.set("kp",  my_speed.kp, 2)
# lcd.p0data7.set("kd2",  my_speed.kd2, 0.02)
# lcd.p0data8.set("angle",  angle, 10)
# 
# lcd.p0data1.set("start", start, 1)
# 
# #lcd.p0data2.set("rank", my_speed.rank, 1)
# lcd.p0data3.set("midL", ccd_class.circle.left_error_limit, 1)
# lcd.p0data4.set("midR", ccd_class.circle.right_error_limit, 1)
# 
# lcd.p0data5.set("type",  ccd_class.circle.type, 0.1)
# lcd.p0data6.set("num",  ccd_class.circle.num, 2)
# lcd.p0data7.set("kd2",  kd2, 0.02)
# lcd.p0data8.set("angle",  angle, 10)
# lcd.p0data9.set("speed",  aaa, 10)

# #——————————————————————————————————————————————————————现场比赛用
# lcd.p0data1.set("rank", my_speed.rank, 1)
# #lcd.p0data2.set("enc", my_speed.enc_judge, 10)
# lcd.p0data2.set("blob1", ccd_class.circle.blob1, 1)
# lcd.p0data3.set("blob2", ccd_class.circle.blob2, 1)
# lcd.p0data4.set("blob3", ccd_class.circle.blob3, 1)
# 
# lcd.p0data5.set("type1", ccd_class.circle.type1, 1)
# lcd.p0data6.set("type2", ccd_class.circle.type2, 1)
# 
# lcd.p0data7.set("c1rate", ccd.c1.threshold_rate, 0.025)
# lcd.p0data8.set("c2rate", ccd.c2.threshold_rate, 0.025)
# lcd.p0data9.set("angle",  angle, 0)
# lcd.p0data10.set("start", start, 1)
# 
# 
# 
# #lcd.p0data4.set("err", ccd_class.circle.ccd_out1, 1)
# lcd.p3data1.set("rank", my_speed.rank, 1)
# lcd.p3data2.set("limRs", ccd_class.circle.right_error_limit_s, 2)
# lcd.p3data3.set("limLm", ccd_class.circle.left_error_limit_m, 2)
# lcd.p3data4.set("limRm", ccd_class.circle.right_error_limit_m, 2)
# lcd.p3data5.set("limLl", ccd_class.circle.left_error_limit_l, 2)
# lcd.p3data6.set("limRl", ccd_class.circle.right_error_limit_l, 2)
# lcd.p3data7.set("kp",  kp, 2)
# 
# lcd.p3data8.set("slowd",  my_speed.Slow_down, 10)
# lcd.p3data9.set("tar",  target_speed, 0)
# lcd.p3data10.set("start", start, 1)
# 
# #lcd.p0data8.set("limLm", ccd_class.circle.left_error_limit_s, 5)
# #lcd.p0data9.set("limRm", ccd_class.circle.right_error_limit_s, 5)
# 
# 
lcd.p1data1.set("start", start, 1)
lcd.p1data2.set("c1rate", ccd.c1.threshold_rate, 0.025)
#lcd.p1data3.set("c2rate", ccd.c2.threshold_rate, 0.025)
#lcd.p1data4.set("ccd_x", lcd.ccd_select, 1)
lcd.p1data3.set("max", ccd.c1.max, 0.025)
lcd.p1data4.set("err", ccd.c1.error, 1)
lcd.p1data5.set("angle",  angle, 0)
lcd.p1data6.set("width",  ccd.c1.width, 0)
# 
# lcd.p2data1.set("blob4", ccd_class.circle.blob4, 1)
# lcd.p2data2.set("type3", ccd_class.circle.type3, 1)
# lcd.p2data3.set("type4", ccd_class.circle.type4, 1)
# lcd.p2data4.set("cross", ccd_class.cross.enable, 1)
# lcd.p2data5.set("encL", ccd_class.circle.big_enc, 6)
# #lcd.p2data6.set("angleL", ccd_class.circle.big_angle, 6)
# lcd.p2data6.set("flag", ccd_class.flag.road_type, 1)
# lcd.p2data7.set("start", start, 1)
# lcd.p2data8.set("rank", my_speed.rank, 1)
# lcd.p2data9.set("blob5", ccd_class.circle.blob5, 1)
# lcd.p2data10.set("enc", my_speed.enc_judge, 30)










# lcd.p2data7.set("angel", ccd_class.circle.out_angle, 1)
# lcd.p2data8.set("enc", ccd_class.circle.out_enc1, 1)
# lcd.p2data9.set("fist", ccd_class.circle.first_half_width, 1)
# lcd.p2data10.set("secd", ccd_class.circle.second_half_width, 1)

#——————————————————————————————————————————————————————现场比赛用


# lcd.p0data1.set("start", start, 1)
# lcd.p0data2.set("rank", my_speed.rank, 1)
# lcd.p0data3.set("left1", ccd_class.circle.first_half_width_left_s, 2)
# lcd.p0data4.set("left2", ccd_class.circle.second_half_width_left_s, 2)
# lcd.p0data5.set("angle",  angle, 0)
# lcd.p0data6.set("kp",  kp, 2)
# lcd.p0data7.set("arts",  ccd_class.circle.out_enc1_art_s, 0)
# lcd.p0data8.set("speed",  target_speed, 10)
# lcd.p0data9.set("right1", ccd_class.circle.first_half_width_right_s, 2)
# lcd.p0data10.set("right2", ccd_class.circle.second_half_width_right_s, 2)
# 
# lcd.p1data1.set("start", start, 1)
# lcd.p1data2.set("ccd_x", lcd.ccd_select, 1)
# lcd.p1data3.set("width", width,0)
# lcd.p1data4.set("error", error, 0)
# lcd.p1data5.set("angle",  angle, 0)
# lcd.p1data6.set("flag", ccd_class.flag.road_type, 0)
# 
# lcd.p2data1.set("start", start, 1)
# lcd.p2data2.set("ccd_x", lcd.ccd_select, 1)
# lcd.p2data3.set("c1rate", ccd.c1.threshold, 0.05)
# lcd.p2data4.set("c2rate", ccd.c2.threshold, 0.05)
# lcd.p2data5.set("width", width,0)
# lcd.p2data6.set("statu",    ccd_class.circle.flag, 0)









# r越小越贴测量值P = 1, Q = 0.02, R = 0.05
class kaerman_filter:
    def __init__(self, P = 1, Q = 0.03, R = 0.1, initial_output = 0.0):
        self.P = P
        self.Q = Q
        self.R = R
        self.Output = initial_output
    def update(self, input_value):
        self.P += self.Q
        G = self.P / (self.P + self.R)
        self.Output += G * (input_value - self.Output)
        self.P = (1 - G)*self.P
        return self.Output
    
    
    
    

class my_pid:
    def __init__(self, kp, ki, kd):
        self.Kp = kp
        self.Ki = ki
        self.Kd = kd
        self.integral = 0
        self.err_last = 0
        self.location_last = 0
 
    def angle_compute(self, target, angle, gyro):
        error = target - angle
        output = self.Kp * error + self.Kd * (angle - self.err_last)
        self.err_last = angle
        #output = self.Kp * error + self.Kd * gyro
        return output
    def angle_gx_compute(self, target, gyro):
        error = target - gyro
        output = self.Kp * error + self.Kd * (error - self.err_last)
        self.err_last = error
        return output
    
    def speed_compute(self, Target, Encoder_L, Encoder_R):
        a = 0.8
        #1.计算偏差
        err=(Encoder_L+Encoder_R)/2-Target
        #2.低通滤波
        err_lowout=(1-a)*err+a*self.err_last
        self.err_last=err_lowout
        #3.积分
        self.integral+=err_lowout
        #4.积分限幅
        self.integral=max(-30, min(self.integral, 30))
        #5.速度环计算
        output=self.Kp*err_lowout#+self.Ki*self.integral + self.Kd * (err_lowout - self.err_last)
        return output   
    def turn_compute(self, location, gyro): #自己判断极性
        global kp,kp2,kd,kd2
        
        temp1 = kp[0]*location[0]
        
        temp2 = ccd.ccd_abs(location[0])*location[0]*kp2[0]
        
        ratio = 0.4
        
        if(temp2 > temp1 * ratio or temp2 < temp1 * ratio):
            temp2 = temp1 * ratio
        
        output =  temp1 + temp2 + (location[0] - self.location_last)*kd[0] + gyro*kd2[0]
        self.location_last = location[0]
        return output
    
  

S_kp = -0
angle_pd = my_pid(0, 0, 0)
angle_gx_pd = my_pid(-0, 0, -0)
speed_pi = my_pid(S_kp, S_kp/100, 0)
turn_pd = my_pid(0, 0, 0)
kaerman = kaerman_filter()
uart_read = None
go = 0

def pid_contral_handler(time):
    # 实例化 PIT ticker 模块 参数为编号 [0-3] 最多四个
    global out, angle_out, speed_out
    global angle_pd, angle_gx_pd
    global imu_count, angle_count, gyro_count, speed_count, art_count, art_wait
    global enc1_data, enc2_data
    global Kpa, Kda,Kpg,Kdg, Kps, Kis,Kds, start
    
    global error,width,angle
    global speed,target_speed,uart_read,aaa
    global protect,ensum,turn_out,speed_tim,start_last,gx_filter,kaerman,go,enc_sum_judge,enc_protect
    
    imu_count   = imu_count + 1
    angle_count = angle_count + 1
    gyro_count  = gyro_count + 1
    speed_count = speed_count + 1
    
    if(start[0] == 2):
        art_count = art_count + 1
    
    angle_gx_pd.Kp = Kpg[0]
    angle_gx_pd.Kd = Kdg[0]
    angle_pd.Kp = Kpa[0]
    angle_pd.Kd = Kda[0]
    speed_pi.Kp = Kps[0]
    speed_pi.Ki = Kps[0]/100
    speed_pi.Kd = Kds[0]
    
    
    my_last[0] = speed
    #art延迟启动
    if art_count == 150 and art_wait == 1:
        uart.uart6.write('N')
        art_count = 0
        art_wait = 0
    
    #30ms中断
    if speed_count == 3:
        
        my_speed.select()    #选择不同的速度参数
        
        if start[0] != 2:        #没有启动时，openart接受数据无效
            uart.art_color[0] = None
            
            
        
        
        if start[0] == -1:#停车线
            speed_out = max(-600, min(speed_pi.speed_compute(0, enc1_data, enc2_data), 400))
            ccd_class.stop.enc[0] += (enc1_data + enc2_data) / 2
            if(ccd_class.stop.enc[0] < -100 * 200):
                start[0] = 0
            #speed_out = speed_pi.speed_compute(0, enc1_data, enc2_data)
            
        elif(start[0] == 0):#初始化
            ccd_check.beep.low()
            ccd_class.flag.reset()
            ccd_class.line.reset()
            ccd_class.box.reset()
            ccd_class.cross.reset()
            ccd_class.circle.reset()
            ccd_class.stop.reset()
            ccd_class.out.reset()
            uart.uart6.write('F')
            art_count = 0
            art_wait = 1
            speed = -60
            speed_out = 0
            
        elif start[0] == 1:#仅平衡
            speed_out = speed_pi.speed_compute(0, enc1_data, enc2_data)
            speed = -60
        
        elif start[0] == 2:#启动出发s
            speed_out = max(my_speed.limit_jia, min(speed_pi.speed_compute(speed, enc1_data, enc2_data), my_speed.limit_jian))
#             speed_out = speed_pi.speed_compute(speed, enc1_data, enc2_data)
#             speed_out = max(my_speed.limit_jia, speed_pi.speed_compute(speed, enc1_data, enc2_data))


            
                            
            if(speed > target_speed[0]):#加速度
                speed -= 5      
            if(my_speed.enc_flag[0] == 1):#减速度
                speed = my_speed.Slow_down[0]
#             elif(speed < target_speed[0]):#减速度
#                 speed += 10


                


        else:#其他情况
            speed = 0
            speed_out = 0
            
        speed_count = 0#清楚中断计数标志位
        
        
        if(lcd.ccd_select[0] == 0):#摄像头1，摄像头2 选择
            error[0] = ccd_class.flag.error[0]
            width[0] = ccd.c1.width[0]
        elif (lcd.ccd_select[0] == 1):      
            error[0] = ccd.c2.error[0]
            width[0] = ccd.c2.width[0]
        
    #20ms中断
    if angle_count == 2:
        #uart.send(imu.data.temp_angle, 222)
        if start[0] != 0:
            angle_out = angle_pd.angle_compute(speed_out, imu.data.temp_angle-imu_0[0], imu.data.gx)
        else:
            angle_out = 0

        angle_count = 0#清楚中断计数标志位
      
        #print(imu.data.temp_angle)
    
    #10ms中断
    if gyro_count == 1:
#         print(imu.data.temp_angle)
        aaa[0] = speed
        uart.openart_read()       #openart数据获取
        
        imu.data.angle_calc()     #陀螺仪数据获取
        if(imu.data.gx<5 and imu.data.gx>-5):
            imu.data.gx = 0
        
        key.get5_8()               #按键数据获取
        enc1_data = encoder_1.get()#编码器数据获取
        enc2_data = encoder_2.get()#编码器数据获取
        

        
        if start[0] == 2:
            pass
            #my_speed.change()       #art检测坡道
            #my_speed.encoder_exit() #编码器退出斜坡
        
            #my_speed.circle_openart_find()  #art检测圆环
            #my_speed.circle_stop()
            my_speed.chose_blob()
      
        else:
            
            my_speed.circle_check_set()     #圆环检测参数动态变化
            my_speed.circle_strategy_set()  #圆环策略参数动态变化
        
        #my_speed.param()    #转向环参数动态变化
        
        #print(imu.data.yaw)
        angle[0] = imu.data.temp_angle
        mgz[0] = imu.data.gz
        
#         if start[0] == 2:
#             enc_sum_judge[0] += (enc1_data + enc2_data) / 2
#             if enc_sum_judge[0] <= -110 * 200 :
#                 ccd_class.circle.enable[0] = 1
#                 ccd_class.cross.enable[0] = 1
#                 enc_sum_judge[0] = -30000 
#         else:
#             enc_sum_judge[0] = 0
#             ccd_class.circle.enable[0] = 0
#             ccd_class.cross.enable[0] = 0
        


        if start[0] != 0:
            
            #uart.send(0, kaerman.update(imu.data.gx), imu.data.gx) 
            #ensum[0] += (enc1_data + enc2_data) / 2
            
            
            #角速度环
            out = angle_gx_pd.angle_gx_compute(angle_out,imu.data.gx)
            #角速度环      
             
             
            #转向环
            if start[0] == 2 :   #启动出发
                
                #my_speed.change() #openart识别结果进行加减速
                
                ccd.process()
                turn_out = turn_pd.turn_compute(ccd_class.flag.error, imu.data.gz)
                if(turn_out > 7000):
                    turn_out = 7000
                elif(turn_out < -7000):
                    turn_out = -7000
            elif start[0] == -1 : #停车线  
                ccd.process()
                turn_out = 0#turn_pd.turn_compute(ccd_class.flag.error, imu.data.gz)

            else:               #其余情况 
                turn_out = 0
            #转向环
                    
                
                    
            #更改电机占空比
            motor_1.duty(max(-9900, min(out-turn_out, 9900)))
            motor_2.duty(max(-9900, min(out+turn_out, 9900)))
#             motor_1.duty(max(-9900, min(3000, 9900)))
#             motor_2.duty(max(-9900, min(3000, 9900)))

            
            
            #小车保护
            if start[0] == 2 and (imu.data.temp_angle - imu_0[0] > 720 or imu.data.temp_angle - imu_0[0] < -1900):
                if(my_speed.enc_flag == 0):
                    start[0] = 0

            if enc1_data >= enc_protect[0] or enc2_data >= enc_protect[0]:
                start[0] = 0
                
            elif enc1_data <= -enc_protect[0] or enc2_data <= -enc_protect[0]:
                start[0] = 0
            #小车保护
                
                
        else:
            motor_1.duty(0)
            motor_2.duty(0)
            
        start_last[0] = start[0]
        gyro_count = 0#清楚中断计数标志位
        

    
def pid_contral_ticker():
    pit1 = ticker(1)
    pit1.capture_list(imu.imu, encoder_1, encoder_2, ccd.ccd)
    pit1.callback(pid_contral_handler)
    pit1.start(10)

