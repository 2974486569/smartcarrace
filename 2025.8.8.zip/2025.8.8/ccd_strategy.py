
# 本示例程序演示如何使用 smartcar 库的 ADC_Group 类接口
# 使用 RT1021-MicroPython 核心板搭配对应拓展学习板的四路电磁运放接口

# 示例程序运行效果为每 200ms(0.2s) C4 LED 改变亮灭状态
# 并通过 Type-C 的 CDC 虚拟串口输出一次信息
# 当 D9 引脚电平出现变化时退出测试程序

# ADC_Group 的采集周期计算方式
# Ticker 通过 start(y) 启动时 y 代表 Ticker 的周期
# 此时每 y 毫秒会触发一次 ADC_Group 的更新
# 因此 ADC_Group 的采集周期时间等于 y 本例程中就是 10ms

# 从 machine 库包含所有内容
from machine import *

# 包含 gc 类
import gc
import time
import ccd
import ccd_class as cs
import pid
import imu
import ccd_check
import my_speed

def common():

    cs.flag.error[0] = ccd.c1.error[0]
    #ccd_check.beep.low()
    
def line():
    cs.flag.error[0] = ccd.c1.error[0]
    
def cross():
    
    if cs.cross.flag[0] == 0:
        if(cs.flag.error[0] > 1):
            cs.flag.error[0] = 0
        elif(cs.flag.error[0] < -1):
            cs.flag.error[0] = 0
            
        if(ccd.c2.width[0] < cs.cross.c2_width_out[0]):
            cs.cross.flag[0] = 1

    elif cs.cross.flag[0] == 1:
        
        cs.flag.error[0] = ccd.c2.error[0] * 0.6
        if(cs.flag.error[0] > 4):
            cs.flag.error[0] = 4
        elif(cs.flag.error[0] < -4):
            cs.flag.error[0] = 4
        
        if(ccd.c1.width[0] < cs.cross.c1_width_out[0]): #视觉退出
            cs.cross.encoder_sum[0] = 0
            cs.flag.road_type[0] = 0
            cs.cross.flag[0] = 0
            ccd_check.beep.low()
            
            
            
    cs.cross.encoder_sum[0] += (pid.enc1_data + pid.enc2_data) / 2  #编码器退出
    
    if(cs.cross.encoder_sum[0] < -100 * 50):
        cs.cross.encoder_sum[0] = 0
        cs.flag.road_type[0] = 0
        cs.cross.flag[0] = 0
        ccd_check.beep.low()




    
def circle():
#rank
    if(cs.circle.num[0] == 1): #第一个圆环 
        cs.circle.type[0] = cs.circle.type1[0]
    elif(cs.circle.num[0] == 2):#第二个圆环 
        cs.circle.type[0] = cs.circle.type2[0]            
    elif(cs.circle.num[0] == 3):#第三个圆环 
        cs.circle.type[0] = cs.circle.type3[0]
    elif(cs.circle.num[0] == 4):#第四个圆环 
        cs.circle.type[0] = cs.circle.type4[0]
        
#     if (my_speed.rank[0] == 0): #160
#         cs.circle.out_enc1_art[0] = cs.circle.out_enc1_art0[0]
#     elif (my_speed.rank[0] == 1):#200
#         cs.circle.out_enc1_art[0] = cs.circle.out_enc1_art1[0]
#     elif (my_speed.rank[0] == 2):#250
#         cs.circle.out_enc1_art[0] = cs.circle.out_enc1_art2[0]
#     elif (my_speed.rank[0] == 3):#275
#         cs.circle.out_enc1_art[0] = cs.circle.out_enc1_art3[0]
#     elif (my_speed.rank[0] == 4):#290
#         cs.circle.out_enc1_art[0] = cs.circle.out_enc1_art4[0]
#     elif (my_speed.rank[0] == 4):#310
#         cs.circle.out_enc1_art[0] = cs.circle.out_enc1_art5[0]
        
        
    if(cs.circle.type[0] == 1):
        
        cs.circle.out_angle[0] = cs.circle.out_angle_s[0]
        
        if cs.circle.judge[0] == 1:
            cs.circle.out_enc1[0] = cs.circle.out_enc1_art_s[0]
        else:
            cs.circle.out_enc1[0] = cs.circle.out_enc1_s[0]
        
        cs.circle.out_enc2[0] = cs.circle.out_enc2_s[0]
        cs.circle.out_enc3[0] = cs.circle.out_enc3_s[0]
        
        if(cs.flag.road_type[0] == 3):#左圆环
            
            cs.circle.first_half_width[0] = cs.circle.first_half_width_left_s[0]
            cs.circle.second_half_width[0] = cs.circle.second_half_width_left_s[0]
        else:
            cs.circle.first_half_width[0] = cs.circle.first_half_width_right_s[0]
            cs.circle.second_half_width[0] = cs.circle.second_half_width_right_s[0]
        
        cs.circle.left_error_limit[0] = cs.circle.left_error_limit_s[0]
        cs.circle.right_error_limit[0] = cs.circle.right_error_limit_s[0]
        
        
    if(cs.circle.type[0] == 2):
        
        cs.circle.out_angle[0] = cs.circle.out_angle_m[0]
        
        if cs.circle.judge[0] == 1:
            cs.circle.out_enc1[0] = cs.circle.out_enc1_art_m[0]
        else:
            cs.circle.out_enc1[0] = cs.circle.out_enc1_m[0]
            
            
        cs.circle.out_enc2[0] = cs.circle.out_enc2_m[0]
        cs.circle.out_enc3[0] = cs.circle.out_enc3_m[0]
        
        
        
        if(cs.flag.road_type[0] == 3):#左圆环
        
            cs.circle.first_half_width[0] = cs.circle.first_half_width_left_m[0]
            cs.circle.second_half_width[0] = cs.circle.second_half_width_left_m[0]
        else:
            cs.circle.first_half_width[0] = cs.circle.first_half_width_right_m[0]
            cs.circle.second_half_width[0] = cs.circle.second_half_width_right_m[0]
        
        cs.circle.left_error_limit[0] = cs.circle.left_error_limit_m[0]
        cs.circle.right_error_limit[0] = cs.circle.right_error_limit_m[0]
        
        
    if(cs.circle.type[0] == 3):
        
        cs.circle.out_angle[0] = cs.circle.out_angle_l[0]
        
        if cs.circle.judge[0] == 1:
            cs.circle.out_enc1[0] = cs.circle.out_enc1_art_l[0]
        else:
            cs.circle.out_enc1[0] = cs.circle.out_enc1_l[0]
            
            
        cs.circle.out_enc2[0] = cs.circle.out_enc2_l[0]
        cs.circle.out_enc3[0] = cs.circle.out_enc3_l[0]
        
        if(cs.flag.road_type[0] == 3):#左圆环
        
            cs.circle.first_half_width[0] = cs.circle.first_half_width_left_l[0]
            cs.circle.second_half_width[0] = cs.circle.second_half_width_left_l[0]
        else:
            cs.circle.first_half_width[0] = cs.circle.first_half_width_right_l[0]
            cs.circle.second_half_width[0] = cs.circle.second_half_width_right_l[0]
        
        cs.circle.left_error_limit[0] = cs.circle.left_error_limit_l[0]
        cs.circle.right_error_limit[0] = cs.circle.right_error_limit_l[0]
        
        
        
        
            

    cs.circle.encoder_sum[0] += (pid.enc1_data + pid.enc2_data) / 2  #编码器退出
    
 
    if(cs.circle.flag[0] == 0):#状态机 0
        
        cs.circle.set_width[0] = cs.line.width[0]#设置补线值
    
        if(cs.flag.road_type[0] == 3):
            cs.circle.virtual_middle[0] = ccd.c1.boundary_right[0]-(cs.circle.set_width[0]/2)-cs.circle.line_left[0]#右边线补左边线
        else:
            cs.circle.virtual_middle[0] = ccd.c1.boundary_left[0]+(cs.circle.set_width[0]/2) + cs.circle.line_right[0]#左边线补右边线
        
        cs.flag.error[0] = -(ccd.c1.image_middle[0] - cs.circle.virtual_middle[0]) #寻找偏差
        
#         cs.flag.error1[0] = ccd.ccd_abs(ccd.c1.error[0])
#         
#         if(cs.circle.encoder_sum[0] < -100 * (cs.circle.out_enc1[0] - 30)):#编码器推出
#             if(cs.circle.ccd_out_flag[0] >= 0 or cs.circle.ccd_out_flag[0] < 10):
#             
#                 if( cs.flag.error1[0] >= cs.circle.ccd_out1[0] ):
#                     cs.circle.ccd_out_flag[0] += 1 
#         
#             if(cs.circle.ccd_out_flag[0] >= 10 or cs.circle.ccd_out_flag[0] < 20):
#                 if( cs.flag.error1[0] <= cs.circle.ccd_out2[0] ):
#                     cs.circle.ccd_out_flag[0] += 1
#                     
#             if(cs.circle.ccd_out_flag[0] >= 20 or cs.circle.ccd_out_flag[0] < 30):
#             
#                 if( cs.flag.error1[0] >= cs.circle.ccd_out1[0] ):
#                     cs.circle.ccd_out_flag[0] += 1     
#                 
# 
#             if(cs.circle.ccd_out_flag[0] >= 30):
#                 cs.circle.encoder_sum[0] = 0
#                 cs.circle.ccd_out_flag[0] = 0 
#                 cs.circle.flag[0] = 1
#                 cs.circle.angle[0] = imu.data.yaw
            
        
        if(cs.circle.encoder_sum[0] < -100 * cs.circle.out_enc1[0] ):#编码器推出
            cs.circle.encoder_sum[0] = 0
            cs.circle.flag[0] = 1
            cs.circle.angle[0] = imu.data.yaw
                     
            
    elif(cs.circle.flag[0] == 1):#状态机1
          
            
        if( ccd.ccd_abs(cs.circle.angle[0] - imu.data.yaw) < cs.circle.out_angle[0] * 0.5):#判断是否跑完一半圆环
            cs.circle.set_width[0] = cs.circle.first_half_width[0]  
        else:
            cs.circle.set_width[0] = cs.circle.second_half_width[0]
            
        if(ccd.c1.width[0] < cs.circle.set_width[0]  and  cs.circle.type[0] == 1):
            cs.circle.set_width[0] = ccd.c1.width[0]
            
        if(ccd.c1.width[0] < cs.circle.set_width[0]  and  cs.circle.type[0] == 3):
            cs.circle.set_width[0] = ccd.c1.width[0]


        if( ccd.ccd_abs(cs.circle.angle[0] - imu.data.yaw) < cs.circle.out_angle[0] * 0.5):#判断是否跑完一半圆环
            if(cs.flag.road_type[0] == 3):
                cs.circle.virtual_middle[0] = ccd.c1.boundary_left[0]+(cs.circle.set_width[0]/2)#左边线补右
            else:
                cs.circle.virtual_middle[0] = ccd.c1.boundary_right[0]-(cs.circle.set_width[0]/2)#右边线补左
            
            cs.flag.error[0] = -(ccd.c1.image_middle[0] - cs.circle.virtual_middle[0]) #寻找偏差
            
        else:
            
            if(cs.circle.type[0] == 3):
            
                if(cs.flag.road_type[0] == 3):
                    
                    cs.circle.virtual_middle[0] = ccd.c1.boundary_left[0]+(cs.circle.set_width[0]/2)#左边线补右
                else:
                    cs.circle.virtual_middle[0] = ccd.c1.boundary_right[0]-(cs.circle.set_width[0]/2)#右边线补左
            
                cs.flag.error[0] = -(ccd.c1.image_middle[0] - cs.circle.virtual_middle[0]) #寻找偏差
                
                
            else:
                if(cs.flag.road_type[0] == 3):
                    cs.flag.error[0] = cs.circle.left_error_limit[0]
                    #pid.start[0] = 0
                else:
                    cs.flag.error[0] = cs.circle.right_error_limit[0]
                    #pid.start[0] = 0

                    


        if( ccd.ccd_abs(cs.circle.angle[0] - imu.data.yaw) >= cs.circle.out_angle[0]): #陀螺仪出圆环
            cs.circle.encoder_sum[0] = 0
            cs.circle.flag[0] = 2
        
            ccd_check.beep.low()
            
        if(cs.circle.encoder_sum[0] < -100 * cs.circle.out_enc2[0]):  #编码器出圆环

            cs.flag.road_type[0] = 0
            cs.circle.flag[0] = 0
            cs.circle.set_width[0] = cs.circle.virtual_middle[0] = cs.circle.angle[0] = 0
            cs.circle.encoder_sum[0] = 0
            
            cs.circle.num[0] -= 1
            cs.circle.judge[0] = 0
            cs.circle.stop[0] = 1

            ccd_check.beep.low()
  

    elif(cs.circle.flag[0] == 2):#状态机2
        
        
        cs.circle.set_width[0] = cs.line.width[0]         #设置补线值
        
        
        if(cs.flag.road_type[0] == 3):
            cs.circle.virtual_middle[0] = ccd.c1.boundary_right[0]-(cs.circle.set_width[0]/2)-cs.circle.line_left[0]#右边线补左
         
        else:
            cs.circle.virtual_middle[0] = ccd.c1.boundary_left[0]+(cs.circle.set_width[0]/2) + cs.circle.line_right[0]#左边线补右


        cs.flag.error[0] = -(ccd.c1.image_middle[0] - cs.circle.virtual_middle[0]) #寻找偏差
 
 
        
        
        if(cs.circle.encoder_sum[0] < -100 * cs.circle.out_enc3[0]):  #编码器出圆环
            cs.flag.road_type[0] = 0
            cs.circle.flag[0] = 0
            cs.circle.set_width[0] = cs.circle.virtual_middle[0] = cs.circle.angle[0] = 0
            cs.circle.encoder_sum[0] = 0
            
            cs.circle.num[0] += 1
            cs.circle.blob_num[0] += 1
            
            cs.circle.judge[0] = 0
            cs.circle.stop[0] = 1

            
        if(cs.circle.type[0] == 3):
            if(cs.circle.encoder_sum[0] < -100 * 150 and ccd.c1.width[0] < cs.line.width[0] + 6):#摄像头判断是否出圆环
                cs.flag.road_type[0] = 0
                cs.circle.flag[0] = 0
                cs.circle.set_width[0] = cs.circle.virtual_middle[0] = cs.circle.angle[0] = 0
                cs.circle.encoder_sum[0] = 0
            
                cs.circle.num[0] += 1
                cs.circle.blob_num[0] += 1
            
                cs.circle.judge[0] = 0
                cs.circle.stop[0] = 1
        else:
            if(cs.circle.encoder_sum[0] < -100 * 60 and ccd.c1.width[0] < cs.line.width[0] + 6):#摄像头判断是否出圆环
                cs.flag.road_type[0] = 0
                cs.circle.flag[0] = 0
                cs.circle.set_width[0] = cs.circle.virtual_middle[0] = cs.circle.angle[0] = 0
                cs.circle.encoder_sum[0] = 0
            
                cs.circle.num[0] += 1
                cs.circle.blob_num[0] += 1
            
                cs.circle.judge[0] = 0
                cs.circle.stop[0] = 1
            



def box():

    
    
    if(cs.flag.road_type[0] == 5): #左
        cs.box.middle[0] = ccd.c1.boundary_middle[0] - cs.box.set_width[0]
    else:  #右
        cs.box.middle[0] = ccd.c1.boundary_middle[0] + cs.box.set_width[0]
        

    cs.flag.error[0] = -1 * (ccd.c1.image_middle[0] - cs.box.middle[0]) #寻找偏差
    
    cs.box.encoder_sum[0] += (pid.enc1_data + pid.enc2_data) / 2
    
    if(cs.box.encoder_sum[0] < -100 * 50):
    
        cs.box.encoder_sum[0] = 0
        cs.box.middle[0] = 0
        
        cs.flag.road_type[0] = 0
        ccd_check.beep.low()


def ramp():
    if(cs.flag.error[0] >= 3):
        cs.flag.error[0] = 3
    elif(cs.flag.error[0] <= -3):
        cs.flag.error[0] = -3
    
    cs.ramp.encoder_sum[0] += (pid.enc1_data + pid.enc2_data) / 2
    if(cs.ramp.encoder_sum[0] < -100 * 65): 
        cs.ramp.encoder_sum[0] = 0
        cs.flag.road_type[0] = 0
        ccd_check.beep.low()


def stop():
    pid.start[0] = -1
    cs.flag.road_type[0] = 0
    cs.stop.enable[0] = 0
    ccd_check.beep.low()
    pass

def out():
    pid.start[0] = 0
    cs.flag.road_type[0] = 0
    ccd_check.beep.low()
    pass
def aaoi():
    pass
    

            




def circle1():
    
    cs.circle.set_width[0] = cs.line.width[0]#设置补线值
    
    if(cs.flag.road_type[0] == 3):
        cs.circle.virtual_middle[0] = ccd.c1.boundary_right[0]-(cs.circle.set_width[0]/2)#右边线补左边线
    else:
        cs.circle.virtual_middle[0] = ccd.c1.boundary_left[0]+(cs.circle.set_width[0]/2)#左边线补右边线
        
    cs.flag.error[0] = -(ccd.c1.image_middle[0] - cs.circle.virtual_middle[0]) #寻找偏差



    cs.circle.encoder_sum[0] += (pid.enc1_data + pid.enc2_data) / 2 
    if(cs.circle.encoder_sum[0] < -110 * 160):
    
        cs.circle.encoder_sum[0] = 0
        cs.circle.virtual_middle[0] = cs.circle.set_width[0] = 0
        cs.flag.road_type[0] = 0
        ccd_check.beep.low()
        


