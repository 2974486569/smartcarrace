from machine import *
import pid
import ccd
import ccd_class
import ccd_strategy
import imu

beep    = Pin('D24', Pin.OUT, value = False)
beep.low()



#//弯道0，直线道路1，十字路口2，左圆环3，右圆环4，右障碍物5，左障碍物6，斜坡7，停止线8, 冲出赛道和环境光照过暗9


def line():    #直线检测
    if(ccd_class.line.enable[0] != 0 ):
        temp = ccd.ccd_abs(ccd.c1.boundary_middle[0] - ccd.c2.boundary_middle[0])
        #temp <= ccd_class.line.threshold[0] and 
        if(ccd.ccd_abs(imu.data.mygz) <= ccd_class.line.gz_threshold[0]-10):           
            ccd_class.flag.road_type[0] = 1
            #beep.high()
        else:
            ccd_class.flag.road_type[0] = 0


def cross():   #十字路口检测
    

    
    #if(ccd_class.cross.enable[0] == 0):
#     ccd_class.cross.encoder_sum_global[0] += (pid.enc1_data + pid.enc2_data) / 2
#     if(ccd_class.cross.encoder_sum_global[0] < -100 * 340):#进十字后走一段路程才开始检测圆环
#             ccd_class.circle.enable[0] = 1
#     if(ccd_class.cross.encoder_sum_global[0] < -100 * 800):#限幅
#         ccd_class.cross.encoder_sum_global[0] = -100 * 800
        
            #ccd_class.cross.encoder_sum_global[0] = 0
   # if ccd_class.cross.num[0] % 2 == 0:
        #ccd_class.cross.enable[0] = 1
        #ccd_class.cross.encoder_sum_global[0] = 0
            
            
    if(ccd_class.cross.enable[0] == 1 and ccd.c2.cross_or_circle[0] <= 15):
        if( ccd.c2.width[0] >= ccd_class.cross.c2_width_in[0]):# and 
            ccd_class.cross.check_flag = 1
            
        if ccd_class.cross.check_flag == 1:
            ccd_class.cross.check_time += 1
        
            if ccd_class.cross.check_time <= 50:
                if (ccd.c1.width[0] > ccd_class.cross.c1_width_in[0] and ccd.c1.cross_or_circle[0] <= 15):
                    
                    
                    ccd_class.flag.road_type[0] = 2   #十字路口
                    ccd_class.cross.num[0] += 1       #计数
                    beep.high() 
                    ccd_class.stop.enable[0] = 1      #停车线使能
#                     ccd_class.circle.enable[0] = 0
#                     ccd_class.cross.encoder_sum_global[0] = 0
            
                    ccd_class.cross.check_flag = 0
                    ccd_class.cross.check_time = 0
            
            else:
            
                ccd_class.cross.check_flag = 0
                ccd_class.cross.check_time = 0
            
            
            

def circle():  #圆环检测

        
        if( ccd.c2.width[0] <= ccd_class.circle.c2_width_in_max[0] and ccd_class.circle.enable[0] == 1
            and ccd.c2.width[0] >= ccd_class.circle.c2_width_in_min[0]
            and ccd.c1.width[0] > ccd.c1.width_last[0]
            and ccd.c1.width_last[0] != 0 
            and ccd.ccd_abs(imu.data.mygz) <= ccd_class.line.gz_threshold[0]-10) :
            
            if( (ccd.c1.boundary_middle_last[0] - ccd.c1.boundary_middle[0]) >= ccd_class.circle.boundary_change[0]):

                ccd_class.flag.road_type[0] = 3 #左圆环
                ccd_class.stop.enable[0] = 1#使能停车线
                ccd_class.circle.num[0] += 1
                beep.high()

            elif( (ccd.c1.boundary_middle_last[0] - ccd.c1.boundary_middle[0]) <= -ccd_class.circle.boundary_change[0]):

                ccd_class.flag.road_type[0] = 4 #右圆环
                ccd_class.stop.enable[0] = 1#使能停车线
                ccd_class.circle.num[0] += 1
                beep.high()
                

    
def box():     #障碍物检测
    
    width_change = ccd.c1.width_last[0] - ccd.c1.width[0]#宽度突变值
    if(ccd.c1.width_last[0] < 50 and ccd.c1.width[0] < 42 and ccd.c1.width_last[0] != 0 and ccd.c1.width[0] != 0):
        if width_change >= ccd_class.box.threshold[0] :  #宽度突变且赛道宽度小于平常宽度
            if( ccd.c1.boundary_middle[0] < ccd.c1.image_middle[0] ): #判断障碍物方向
                ccd_class.flag.road_type[0] = 5  #右障碍物
                beep.high()
            else:                                            
                ccd_class.flag.road_type[0] = 6  #左障碍物
                beep.high()


def ramp():   
    
    #encoder_sum_global

    
    if(ccd_class.ramp.distance[0] <= ccd_class.ramp.threshold[0]
       and ccd.ccd_abs(imu.data.mygz) <= ccd_class.line.gz_threshold[0]
       and ccd_class.ramp.distance[0] != 0):
        ccd_class.flag.road_type[0] = 7  #坡道
        beep.high()
        
        
        
        
        
        
        
        

def stop():    #停车线检测

    judge = 0
    bright = 0
    low = 0

    if(ccd_class.stop.enable[0] == 1 and ccd.c1.width[0] < 65 and ccd.c2.width[0] < 60):

        if(ccd.c1.width[0] > 8 and ccd.c2.width[0] > 28 and ccd.ccd_abs(imu.data.mygz) <= ccd_class.line.gz_threshold[0]):
            for i in range(ccd.c1.boundary_left[0]+1, ccd.c1.boundary_right[0]):
                if(ccd.c1.bin_data[i] == 1):
                    bright += 1
                else:
                    low += 1
   
            ccd_class.stop.num_bright[0] = bright
            ccd_class.stop.num_low[0] = low
            if(low > (ccd_class.stop.threshold_rate[0] * bright)):
                judge = 1
        if(judge == 1):
            ccd_class.flag.road_type[0] = 8
            beep.high()

            
            

def out(): #出界检测

    if(ccd.c1.width[0] == 0):
        #if(ccd.c2.width[0] == 0):
        ccd_class.flag.road_type[0] = 9
        beep.high()
    #if(ccd.ccd_abs(ccd.c1.boundary_right[0] - ccd.c1.boundary_left[0]) < 15):
        #ccd_class.flag.road_type[0] = 9
        #beep.high()
            
    #if (ccd.c1.max[0] <= ccd.c1.max_global[0] * 0.5):
        #ccd_class.flag.road_type[0] = 9
        #beep.high()
        




    


    








