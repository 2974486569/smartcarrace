
# 本示例程序演示如何使用 seekfree 库的 KEY_HANDLER 类接口
# 使用 RT1021-MicroPython 核心板搭配对应拓展学习板的按键测试

# 示例程序运行效果为每 1000ms(1s) C4 LED 改变亮灭状态
# 当按键短按或者长按时通过 Type-C 的 CDC 虚拟串口输出信息
# 当 D9 引脚电平出现变化时退出测试程序

# KEY_HANDLER 的扫描周期计算方式
# Ticker 通过 start(y) 启动时 y 代表 Ticker 的周期
# 此时每 y 毫秒会触发一次 KEY_HANDLER 的更新
# 因此 KEY_HANDLER 的采集周期时间等于 y 本例程中就是 10ms

# 从 machine 库包含所有内容
from machine import *

# 包含 gc 与 time 类
import gc
import time
import ccd_check
import ccd_strategy
import ccd_class
import pid
import ccd



def check():
    
    if(ccd_class.flag.road_type[0] == 0 or ccd_class.flag.road_type[0] == 1):
        if(pid.start[0] != 0):
            pass
            ccd_check.line()
            
            
            #ccd_check.circle()
            ccd_check.cross()
            
            #ccd_check.box()
            #ccd_check.ramp()
            
        if(pid.start[0] == 2):
            pass
            #ccd_check.stop()
            #ccd_check.out()

    
def strategy():
    if(ccd_class.flag.road_type[0] == 0):
        ccd_strategy.common()
        
    elif(ccd_class.flag.road_type[0] == 1):
        ccd_strategy.line()
    
    elif(ccd_class.flag.road_type[0] == 2):
        ccd_strategy.cross()
    
    elif(ccd_class.flag.road_type[0] == 3):
        ccd_strategy.circle()
    
    elif(ccd_class.flag.road_type[0] == 4):
        ccd_strategy.circle()

    elif(ccd_class.flag.road_type[0] == 5):
        ccd_strategy.box()

    elif(ccd_class.flag.road_type[0] == 6):
        ccd_strategy.box()

    elif(ccd_class.flag.road_type[0] == 7):
        ccd_strategy.ramp()
   
    elif(ccd_class.flag.road_type[0] == 8):
        ccd_strategy.stop()
        
    elif(ccd_class.flag.road_type[0] == 9):
        ccd_strategy.out()



