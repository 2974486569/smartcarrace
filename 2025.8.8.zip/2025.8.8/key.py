#按键初始化函数
#
#请勿放进中断里，在主循环里通过key.get()获取按键数据
#按键1的值为key.data[0]     按键2的值为key.data[1]     按键3的值为key.data[2]    按键4的值为key.data[3]  
#
#版本V1.0
#温昊4.18

from machine import *
from seekfree import KEY_HANDLER
import gc
import time


# 按键初始化
key = KEY_HANDLER(10)

key5     = Pin('B12' , Pin.IN, pull = Pin.PULL_UP_47K, value = True)
key6     = Pin('B14' , Pin.IN, pull = Pin.PULL_UP_47K, value = True)
key7     = Pin('B15' , Pin.IN, pull = Pin.PULL_UP_47K, value = True)
key8     = Pin('B17' , Pin.IN, pull = Pin.PULL_UP_47K, value = True)

data = key.get()# 按键数据为三个状态 0-无动作 1-短按 2-长按,  取值为key_data[0] ~ key_data[3]

data5 = [0]
data6 = [0]
data7 = [0]
data8 = [0]

data5_tick = 0
data6_tick = 0
data7_tick = 0
data8_tick = 0
tick = 3


def get5_8():
    global data5,data6,data7,data8
    global data5_tick,data6_tick,data7_tick,data8_tick,tick
    
    if( key5.value() == 0):
        data5_tick += 1
    if( key5.value() == 1):
        if(data5_tick >= tick):
            data5_tick = 0
            data5[0] = 1
            
    if( key6.value() == 0):
        data6_tick += 1
    if( key6.value() == 1):
        if(data6_tick >= tick):
            data6_tick = 0
            data6[0] = 1
        
    if( key7.value() == 0):
        data7_tick += 1
    if( key7.value() == 1):
        if(data7_tick >= tick):
            data7_tick = 0
            data7[0] = 1
        
    if( key8.value() == 0):
        data8_tick += 1
    if( key8.value() == 1):
        if(data8_tick >= tick):
            data8_tick = 0
            data8[0] = 1

def get():

    
    key.capture()

    
    
    