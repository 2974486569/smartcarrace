#发送对应数据到逐飞助手
#
#在中断里调用uart_send函数即可
#
#
#版本V1.0
#温昊4.17



#导入所需库
from machine import *
from smartcar import ticker
from seekfree import WIRELESS_UART
import gc
import time


#无线传输初始化
wireless = WIRELESS_UART(921600)


#发送变量到逐飞助手示波器, 最多同时发送8个, 有几个数据就填几个, 支持float类型
def send(num1, num2 = 0, num3 = 0, num4 = 0, num5 = 0, num6 = 0, num7 = 0, num8 = 0):
    wireless.send_oscilloscope(num1,num2,num3,num4,num5,num6,num7,num8)
    
    
#发送摄像头数据到逐飞助手
def send_ccd(select):
    
    #仅发送CCD1数据
    if(select == 1):
        wireless.send_ccd_image(WIRELESS_UART.CCD1_BUFFER_INDEX)
    #仅发送CCD2数据
    elif(select == 2):
        wireless.send_ccd_image(WIRELESS_UART.CCD2_BUFFER_INDEX)
    #两者都发送
    elif(select == 3):
        wireless.send_ccd_image(WIRELESS_UART.CCD1_2_BUFFER_INDEX)
    
    
    



buf = None
uart6 = UART(5)
uart6.init(115200)
# time.sleep_ms(3000)
# uart6.write('N')
# uart6.write('F')
def uart_capture():
    buf_len = uart6.any()
    if buf_len:
        buf = uart6.read(buf_len)
        #print(1234)
        return buf
    else:
        return 0


art_color = [0]
def openart_read():
    art_color[0] = uart_capture()
    if art_color[0] != 0:
        #pass
        print("recieve~")
        print(f"{art_color[0]}\n")
            #uart.uart6.write('F')
        

    
