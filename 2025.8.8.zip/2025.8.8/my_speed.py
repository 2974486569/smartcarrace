# 从 machine 库包含所有内容
from machine import *

# 包含 gc 与 time 类
import gc
import time
import ccd_class as cs
import pid
import uart
import ccd
import ccd_check
import imu

tick = [0]
time = [0]
speed = [0]


rank = [0]


target_speed = [0]


kp = [0]
kp2= [0]
kd = [0]
kd2= [0]

kps = [0]
kpg = [0]
kpa = [0]

Slow_down = [-150]
limit_jia = 0
limit_jian = 0
limit_jia_temp = 0
limit_jian_temp = 0
start_flag = 1


enc_sum = 0
enc_flag = [0]  
enc_judge = [0] #如果大于X厘米，则视为查到绿色色块, 通过更改这个值可以决定走多远后就开始加速
enc_judge2 = [0]
  




#急弯,移近色块，提高c1_rate
#慢弯,移远色块，降低c1_rate

#内切，降低limit
#外切，提高limit

def chose_blob():
    if cs.circle.blob_num[0] == 1:
        cs.circle.blob[0] = cs.circle.blob1[0]
        
    elif cs.circle.blob_num[0] == 2:
        cs.circle.blob[0] = cs.circle.blob2[0]
        
    elif cs.circle.blob_num[0] == 3:
        cs.circle.blob[0] = cs.circle.blob3[0]
        
    elif cs.circle.blob_num[0] == 4:
        cs.circle.blob[0] = cs.circle.blob4[0]
        
    elif cs.circle.blob_num[0] == 5:
        cs.circle.blob[0] = cs.circle.blob5[0]
        
    elif cs.circle.blob_num[0] == 6:
        cs.circle.blob[0] = cs.circle.blob6[0]
        
        
    if cs.circle.blob[0] == 1:#左圆环，
        circle_openart_find_left()
    if cs.circle.blob[0] == 2:
        circle_openart_find_right()
    if cs.circle.blob[0] == 3:
        change()       #art检测坡道
        encoder_exit() #编码器退出斜坡
#blob_num
#查数
def encoder_exit():
    global target_speed,kp,kp2,kd2,kps,kpg,kpa,rank
    global start_flag,kps,enc_judge,enc_flag,enc_sum, limit_jia, limit_jian, limit_jia_temp, limit_jian_temp,enc_judge2
#     if((pid.enc1_data + pid.enc2_data) / 2 < 200):
#         pid.Kpa[0] = 2.3
        
    if(enc_flag[0] == 1):
        
        real_speed = (pid.enc1_data + pid.enc2_data) / 2 #计算当前速度
        
        rate = real_speed / (target_speed[0]+1)           #当前速度与期望速度的比值，范围 %0 到 %100
        if(rate > 1):
            rate = 1
    

        
        
        
        enc_sum += (pid.enc1_data + pid.enc2_data) / 2  #编码器计数
        
        if (enc_sum > -114 * 100):
            
            pid.kp[0] =  (0.1 + 0.9* rate)*45              #越接近期望速度，转向环参数就越接近我们设定的值
            pid.kp2[0] = (0.1 + 0.9* rate)*1
            pid.kd2[0] = (0.1 + 0.9* rate)*0.15
            

        
        if (enc_sum < -114 * enc_judge[0]): 
            enc_flag[0] = 2
            enc_sum = 0
            limit_jia = limit_jia_temp
            limit_jian = limit_jian_temp
            
            uart.art_color[0] = None
            
            

            
            #cs.stop.enable[0] = 1 #开启停车线检测
    if(enc_flag[0] == 2):
        
#         real_speed = (pid.enc1_data + pid.enc2_data) / 2 #计算当前速度
        
#         rate = real_speed / (target_speed[0]+1)           #当前速度与期望速度的比值，范围 %0 到 %100
#         if(rate > 1):
#             rate = 1
#     
#         pid.kp[0] =  (0.1 + 0.9* rate)*45              #越接近期望速度，转向环参数就越接近我们设定的值
#         pid.kp2[0] = (0.1 + 0.9* rate)*1
#         pid.kd2[0] = (0.1 + 0.9* rate)*0.15
        
        if(uart.art_color[0] == b'g'): #红色恢复
    
            enc_flag[0] = 3
            enc_sum = 0
            uart.art_color[0] = None
            ccd_check.beep.low()
            
            #参数还原
            pid.Kps[0] = kps[0]
            pid.Kpa[0] = kpa[0]
            pid.Kpg[0] = kpg[0]
            
            pid.kp[0]  = kp[0]
            pid.kp2[0] = kp2[0]
            pid.kd2[0] = kd2[0]
            
            pid.target_speed[0] = target_speed[0]  



            
    if(enc_flag[0] == 3):
        enc_sum += (pid.enc1_data + pid.enc2_data) / 2  #编码器计数
        if (enc_sum < -114 * 50):#enc_judge[0]): 
            enc_flag[0] = 0
            cs.circle.blob_num[0] += 1
            enc_sum = 0
            uart.art_color[0] = None
            



                        

def change():
    global rank,target_speed,kp,kp2,kd2,kps,kpg,kpa
    global start_flag,enc_judge,enc_flag,enc_sum, limit_jia, limit_jian, Slow_down
    pass

    if(uart.art_color[0] == b'g' and enc_flag[0] == 0): #红色减速
        
        ccd_check.beep.high()
        cs.stop.enable[0] = 0 #关闭停车线检测
        enc_flag[0] = 1 #开始编码器计数

        limit_jian = 800
        limit_jia = -800
        pid.Kpa[0] = 2.3
        
        
        
        #Slow_down[0] = -150#aa
         

        #pid.kp[0] = 45	#转向
        #pid.kp2[0] = 1
        #pid.kd2[0] = 0.15            
        
        pid.target_speed[0] = Slow_down[0]
    
        uart.art_color[0] = None
             
def select():
    
    global rank, kps, kpa, kpg, target_speed, limit_jia, limit_jian, kp, kp2, kd, kd2, limit_jia_temp, limit_jian_temp,enc_judge
    
    #通过rank这个变量来选择不同的速度参数，一键更改
    if pid.start[0] == 0:
        if(rank[0] == 0):  ##第0挡位
        
            pid.kp[0] = 34	#53  转向95
            pid.kp2[0] = -0.45 #0.3
            pid.kd2[0] = 0.32 #0.4
            
            pid.Kpa[0] = 5.5	#直立环
            
            pid.Kps[0] = -4
            
            pid.target_speed[0] = -150   #速度
            limit_jia =   -3000#-250
            limit_jian =   3000#100
            
            enc_judge[0] = 100
            enc_judge2[0] = 50
            
            #圆环参数————————————————————————————————————————————————————————

            #圆环参数————————————————————————————————————————————————————————
            
            limit_jia_temp = limit_jia
            limit_jian_temp = limit_jian
            kps[0] = pid.Kps[0]
            kpa[0] = pid.Kpa[0]
            kpg[0] = pid.Kpg[0]
            kp[0] = pid.kp[0]
            kp2[0] = pid.kp2[0]
            kd2[0] = pid.kd2[0]
            target_speed[0] = pid.target_speed[0]
            
        elif(rank[0] == 1):  ##第1挡位
        
#             pid.kp[0] = 40	#53  转向95
#             pid.kp2[0] = 0.1 #0.3
#             pid.kd2[0] = 0.3 #0.4
            pid.kp[0] = 50	#53  转向95
            pid.kp2[0] = 0.1 #0.3
            pid.kd2[0] = 0.24 #0.4
            
            pid.Kpa[0] = 5.5	#直立环
            
            pid.Kps[0] = -4
            
            pid.target_speed[0] = -200   #速度
#             limit_jia =   -300#-250
#             limit_jian =   90#100
            
            limit_jia = -4000
            limit_jian = 4000 
            
            enc_judge[0] = 100
            enc_judge2[0] = 50
            
            #圆环参数————————————————————————————————————————————————————————

            #圆环参数————————————————————————————————————————————————————————
            
            limit_jia_temp = limit_jia
            limit_jian_temp = limit_jian
            kps[0] = pid.Kps[0]
            kpa[0] = pid.Kpa[0]
            kpg[0] = pid.Kpg[0]
            kp[0] = pid.kp[0]
            kp2[0] = pid.kp2[0]
            kd2[0] = pid.kd2[0]
            target_speed[0] = pid.target_speed[0]
            
        elif(rank[0] == 2):  ##第2挡位
        
            pid.kp[0] = 135
            pid.kp2[0] = 2
#             pid.kd2[0] = 0.8
            pid.kd2[0] = 1
            
            pid.Kpa[0] = 5.5	#直立环
            pid.Kps[0] = -4
            
            pid.target_speed[0] = -250
#             limit_jia =   -300#-250
#             limit_jian =   90#100
            limit_jia = -4000
            limit_jian = 4000
            
            enc_judge[0] = 100
            enc_judge2[0] = 110
            
            #圆环参数————————————————————————————————————————————————————————

            #圆环参数————————————————————————————————————————————————————————
            
            limit_jia_temp = limit_jia
            limit_jian_temp = limit_jian
            kps[0] = pid.Kps[0]
            kpa[0] = pid.Kpa[0]
            kpg[0] = pid.Kpg[0]
            kp[0] = pid.kp[0]
            kp2[0] = pid.kp2[0]
            kd2[0] = pid.kd2[0]
            target_speed[0] = pid.target_speed[0]
        
        elif(rank[0] == 3):  #第3挡位
        
            pid.kp[0] = 175
            pid.kp2[0] = 2.5
#             pid.kd2[0] = 1
            pid.kd2[0] = 1.1           
            pid.Kpa[0] = 5.5	#直立环
            pid.Kps[0] = -4
            
            pid.target_speed[0] = -275
#             limit_jia = -350#-300
#             limit_jian = 90#50
            limit_jia = -4000
            limit_jian = 4000 
            
            enc_judge[0] = 100
            enc_judge2[0] = 140
            
            #圆环参数————————————————————————————————————————————————————————

            #圆环参数————————————————————————————————————————————————————————
            
            
            limit_jia_temp = limit_jia
            limit_jian_temp = limit_jian
            kps[0] = pid.Kps[0]
            kpa[0] = pid.Kpa[0]
            kpg[0] = pid.Kpg[0]
            kp[0] = pid.kp[0]
            kp2[0] = pid.kp2[0]
            kd2[0] = pid.kd2[0]
            target_speed[0] = pid.target_speed[0]
            
        elif(rank[0] == 4):  #第4挡位
#             pid.kp[0] = 210
#             pid.kd2[0] = 1     
            pid.kp[0] = 205
            pid.kp2[0] = 2.5
            pid.kd2[0] = 1.1            
            pid.Kpa[0] = 5.5	#直立环
            pid.Kps[0] = -4
            
            pid.target_speed[0] = -290
            
#             limit_jia = -350
#             limit_jian = 90
            
            limit_jia = -4000
            limit_jian = 4000 
            
            enc_judge[0] = 100
            enc_judge2[0] = 170
#             limit_jia =   -2000#-250
#             limit_jian =   2000#100   
            
            #圆环参数————————————————————————————————————————————————————————

            #圆环参数————————————————————————————————————————————————————————
            
            
            limit_jia_temp = limit_jia
            limit_jian_temp = limit_jian
            kps[0] = pid.Kps[0]
            kpa[0] = pid.Kpa[0]
            kpg[0] = pid.Kpg[0]
            kp[0] = pid.kp[0]
            kp2[0] = pid.kp2[0]
            kd2[0] = pid.kd2[0]
            target_speed[0] = pid.target_speed[0]
            
        elif(rank[0] == 5):  #第5挡位
        
            pid.kp[0] = 235
            pid.kp2[0] = 2.7
            pid.kd2[0] = 1.4
            
            pid.Kpa[0] = 5.5	#直立环
            pid.Kps[0] = -4
            
            pid.target_speed[0] = -310
            limit_jia = -350
            limit_jian = 90
#             limit_jia = -4000
#             limit_jian = 4000            
            enc_judge[0] = 100
            enc_judge2[0] = 170
            
            
            pid.enc_protect[0] = 1150 
#             limit_jia =   -2000#-250
#             limit_jian =   2000#100   
            
            #圆环参数————————————————————————————————————————————————————————

            #圆环参数————————————————————————————————————————————————————————
            
            
            limit_jia_temp = limit_jia
            limit_jian_temp = limit_jian
            kps[0] = pid.Kps[0]
            kpa[0] = pid.Kpa[0]
            kpg[0] = pid.Kpg[0]
            kp[0] = pid.kp[0]
            kp2[0] = pid.kp2[0]
            kd2[0] = pid.kd2[0]
            target_speed[0] = pid.target_speed[0]
            
            
        elif(rank[0] == 6):  #第6挡位
        
            pid.kp[0] = 250
            pid.kp2[0] = 2.7
            pid.kd2[0] = 1.4
            
            pid.Kpa[0] = 5.5	#直立环
            pid.Kps[0] = -4
            
            pid.target_speed[0] = -330
            limit_jia = -350
            limit_jian = 90
            
            enc_judge[0] = 100
            enc_judge2[0] = 170
            
            pid.enc_protect[0] = 1300
            
            #圆环参数————————————————————————————————————————————————————————

            #圆环参数————————————————————————————————————————————————————————
            
            
            limit_jia_temp = limit_jia
            limit_jian_temp = limit_jian
            kps[0] = pid.Kps[0]
            kpa[0] = pid.Kpa[0]
            kpg[0] = pid.Kpg[0]
            kp[0] = pid.kp[0]
            kp2[0] = pid.kp2[0]
            kd2[0] = pid.kd2[0]
            target_speed[0] = pid.target_speed[0]
            
        elif(rank[0] == 7):  #第7挡位
        
            pid.kp[0] = 265
            pid.kp2[0] = 2.7
            pid.kd2[0] = 1.5
            
            pid.Kpa[0] = 5.5	#直立环
            pid.Kps[0] = -4
            
            pid.target_speed[0] = -350

            
            limit_jia = -350
            limit_jian = 90
            
            enc_judge[0] = 100
            enc_judge2[0] = 170
            
            #圆环参数————————————————————————————————————————————————————————

            #圆环参数————————————————————————————————————————————————————————
            
            
            limit_jia_temp = limit_jia
            limit_jian_temp = limit_jian
            kps[0] = pid.Kps[0]
            kpa[0] = pid.Kpa[0]
            kpg[0] = pid.Kpg[0]
            kp[0] = pid.kp[0]
            kp2[0] = pid.kp2[0]
            kd2[0] = pid.kd2[0]
            target_speed[0] = pid.target_speed[0]
            
            
def circle_openart_find_left():
    global target_speed,kp,kp2,kd2,kps,kpg,kpa
    global start_flag,kps,enc_judge,enc_flag,enc_sum, limit_jia, limit_jian, Slow_down
    
    if(uart.art_color[0] == b'g'): #黄色为 左圆环
            
        cs.flag.road_type[0] = 3 #左圆环
        cs.stop.enable[0] = 1#使能停车线
        
        ccd_check.beep.high()
        cs.circle.judge[0] = 1
        uart.art_color[0] = None

        
def circle_openart_find_right():
    global target_speed,kp,kp2,kd2,kps,kpg,kpa
    global start_flag,kps,enc_judge,enc_flag,enc_sum, limit_jia, limit_jian, Slow_down
    
           
    if(uart.art_color[0] == b'g'): #绿色为 右圆环
        
        cs.flag.road_type[0] = 4 #右圆环
        cs.stop.enable[0] = 1#使能停车线

        ccd_check.beep.high()
        cs.circle.judge[0] = 1
        uart.art_color[0] = None
        
def circle_stop():
    if(cs.circle.stop[0] == 1):
        cs.circle.stop_enc[0] += (pid.enc1_data + pid.enc2_data) / 2
        if cs.circle.stop_enc[0] < -110 * 50:
            cs.circle.stop[0] = 0
            cs.circle.stop_enc[0] = 0
            pid.start[0] = -1
        
        
def circle_strategy_set():
    
    global rank, kps, kpa, kpg, target_speed, limit_jia, limit_jian, kp, kp2, kd, kd2, limit_jia_temp, limit_jian_temp
    
    if(rank[0] == 1 and pid.start[0] == 0):
          
        #小圆环200
        cs.circle.line_left[0] = 7#小圆环200
        cs.circle.line_right[0] = 7#小圆环200
        
        cs.circle.out_enc1_art_s[0] = 70#70
        cs.circle.out_angle_s[0] = 350
        cs.circle.out_enc1_s[0]  = 35
        cs.circle.out_enc2_s[0]  = 700
        cs.circle.out_enc3_s[0]  = 70
        


        cs.circle.first_half_width_left_s[0] = 60#71#71  #左圆环，逆时针跑
        cs.circle.second_half_width_left_s[0] = 65#61#61

        cs.circle.first_half_width_right_s[0] = 70#56   #右圆环，顺时针跑
        cs.circle.second_half_width_right_s[0] = 40#25
        
        cs.circle.left_error_limit_s[0]  = -20#-24#小圆环200
        cs.circle.right_error_limit_s[0] =  26#小圆环200
        
        
        
        #中圆环200
        cs.circle.line_left[0] = 7#中圆环200
        cs.circle.line_right[0] = 7#中圆环200
        
        cs.circle.out_enc1_art_m[0] = 95
        cs.circle.out_angle_m[0] = 350
        cs.circle.out_enc1_m[0]  = 40
        cs.circle.out_enc2_m[0]  = 850
        cs.circle.out_enc3_m[0]  = 80
        
        cs.circle.first_half_width_left_m[0] =65
        cs.circle.second_half_width_left_m[0] = 60

        cs.circle.first_half_width_right_m[0] = 57   #右圆环，顺时针跑
        cs.circle.second_half_width_right_m[0] = 70
        #中圆环200
        cs.circle.left_error_limit_m[0] = -20#中圆环200
        cs.circle.right_error_limit_m[0] = 22#中圆环200
        
        
        #大圆环200
        cs.circle.line_left[0] = 7#大圆环200
        cs.circle.line_right[0] = 7#大圆环200
        
        cs.circle.out_enc1_art_l[0] = 95+cs.circle.big_enc[0]
        cs.circle.out_angle_l[0] = 360+cs.circle.big_angle[0]
        cs.circle.out_enc1_l[0]  = 40
        cs.circle.out_enc2_l[0]  = 1200
        cs.circle.out_enc3_l[0]  = 160
        
        cs.circle.first_half_width_left_l[0] =75
        cs.circle.second_half_width_left_l[0] = 75

        cs.circle.first_half_width_right_l[0] = 75   #右圆环，顺时针跑
        cs.circle.second_half_width_right_l[0] = 75
        #大圆环200
        cs.circle.left_error_limit_l[0] = -20#大圆环200
        cs.circle.right_error_limit_l[0] = 22#大圆环200

        
        
            
    elif(rank[0] == 2 and pid.start[0] == 0):

        #小圆环250
        cs.circle.line_left[0] = 9#小圆环250
        cs.circle.line_right[0] = 9#小圆环250
        
        cs.circle.out_enc1_art_s[0] = 88
        cs.circle.out_angle_s[0] = 350
        cs.circle.out_enc1_s[0]  = 35
        cs.circle.out_enc2_s[0]  = 800
        cs.circle.out_enc3_s[0]  = 70
        

        cs.circle.first_half_width_left_s[0] = 71  #左圆环，逆时针跑
        cs.circle.second_half_width_left_s[0] = 74

        cs.circle.first_half_width_right_s[0] = 71   #右圆环，顺时针跑
        cs.circle.second_half_width_right_s[0] = 50
        
        cs.circle.left_error_limit_s[0]  = -20.5#小圆环250
        cs.circle.right_error_limit_s[0] =  22#小圆环250
        
        
        
        #中圆环250        #中圆环250
        cs.circle.line_left[0] = 9
        cs.circle.line_right[0] = 9
        
        cs.circle.out_enc1_art_m[0] = 110     #中圆环250
        cs.circle.out_angle_m[0] = 350             #中圆环250
        cs.circle.out_enc1_m[0]  = 40                #中圆环250
        cs.circle.out_enc2_m[0]  = 900
        cs.circle.out_enc3_m[0]  = 80
        
        cs.circle.first_half_width_left_m[0] = 70  #左圆环，逆时针跑
        cs.circle.second_half_width_left_m[0] = 74

        cs.circle.first_half_width_right_m[0] = 60   #右圆环，顺时针跑
        cs.circle.second_half_width_right_m[0] = 50
        
        cs.circle.left_error_limit_m[0]  = -17  #中圆环250
        cs.circle.right_error_limit_m[0] =  18    #中圆环250
#



        #大圆环250

        cs.circle.line_left[0] = 9#大圆环250
        cs.circle.line_right[0] = 9#大圆环250
        
        cs.circle.out_enc1_art_l[0] = 110+cs.circle.big_enc[0]
        cs.circle.out_angle_l[0] = 360+cs.circle.big_angle[0]
        cs.circle.out_enc1_l[0]  = 40
        cs.circle.out_enc2_l[0]  = 1200
        cs.circle.out_enc3_l[0]  = 170
        
        cs.circle.first_half_width_left_l[0] =75
        cs.circle.second_half_width_left_l[0] = 75

        cs.circle.first_half_width_right_l[0] = 75   #右圆环，顺时针跑
        cs.circle.second_half_width_right_l[0] = 75
        #大圆环250
        cs.circle.left_error_limit_l[0] = -20#大圆环250
        cs.circle.right_error_limit_l[0] = 22#大圆环250
        
        
        
        
    elif(rank[0] == 3 and pid.start[0] == 0):
        #小圆环275
        cs.circle.line_left[0] = 10#小圆环275
        cs.circle.line_right[0] = 10#小圆环275
        
        cs.circle.out_enc1_art_s[0] = 97#小圆环275
        cs.circle.out_angle_s[0] = 340#小圆环275
        cs.circle.out_enc1_s[0]  = 35#小圆环275
        cs.circle.out_enc2_s[0]  = 900
        cs.circle.out_enc3_s[0]  = 70
        

        cs.circle.first_half_width_left_s[0] = 70  #左圆环，逆时针跑
        cs.circle.second_half_width_left_s[0] = 70


        cs.circle.first_half_width_right_s[0] = 70   #右圆环，顺时针跑
        cs.circle.second_half_width_right_s[0] = 70
        
        cs.circle.left_error_limit_s[0]  = -16#小圆环275
        cs.circle.right_error_limit_s[0] =  18#小圆环275
        
        
        
#         #中圆环
        #中圆环275
        cs.circle.line_left[0] = 10
        cs.circle.line_right[0] = 10
        
        cs.circle.out_enc1_art_m[0] = 120#中圆环275
        cs.circle.out_angle_m[0] = 370#中圆环275
        cs.circle.out_enc1_m[0]  = 40#中圆环275
        cs.circle.out_enc2_m[0]  = 900#中圆环275
        cs.circle.out_enc3_m[0]  = 80#中圆环275
        
        cs.circle.first_half_width_left_m[0] = 70  #左圆环，逆时针跑
        cs.circle.second_half_width_left_m[0] = 70

        cs.circle.first_half_width_right_m[0] = 64   #右圆环，顺时针跑
        cs.circle.second_half_width_right_m[0] = 70
        
        cs.circle.left_error_limit_m[0]  = -16#中圆环275
        cs.circle.right_error_limit_m[0] =  16#中圆环275


        #大圆环275

        cs.circle.line_left[0] = 10#大圆环275
        cs.circle.line_right[0] = 10#大圆环275
        
        cs.circle.out_enc1_art_l[0] = 120+cs.circle.big_enc[0]
        cs.circle.out_angle_l[0] = 360+cs.circle.big_angle[0]
        cs.circle.out_enc1_l[0]  = 40
        cs.circle.out_enc2_l[0]  = 1200
        cs.circle.out_enc3_l[0]  = 170
        
        cs.circle.first_half_width_left_l[0] =75
        cs.circle.second_half_width_left_l[0] = 75

        cs.circle.first_half_width_right_l[0] = 75   #右圆环，顺时针跑
        cs.circle.second_half_width_right_l[0] = 75
        #大圆环275
        cs.circle.left_error_limit_l[0] = -20#大圆环275
        cs.circle.right_error_limit_l[0] = 22#大圆环275
    
    elif(rank[0] == 4 and pid.start[0] == 0): #290
        
         #小圆环290
        cs.circle.line_left[0] = 10#小圆环290
        cs.circle.line_right[0] = 10#小圆环290
        
        cs.circle.out_enc1_art_s[0] = 97
        cs.circle.out_angle_s[0] = 350
        cs.circle.out_enc1_s[0]  = 35
        cs.circle.out_enc2_s[0]  = 900
        cs.circle.out_enc3_s[0]  = 70
        

        cs.circle.first_half_width_left_s[0] = 72  #左圆环，逆时针跑
        cs.circle.second_half_width_left_s[0] = 70

        cs.circle.first_half_width_right_s[0] = 75   #右圆环，顺时针跑
        cs.circle.second_half_width_right_s[0] = 70
        
        cs.circle.left_error_limit_s[0]  = -16#小圆环290
        cs.circle.right_error_limit_s[0] = 18#小圆环290
        
        
        #中圆环290
        cs.circle.line_left[0] = 10#中圆环290
        cs.circle.line_right[0] = 10#中圆环290
        
        cs.circle.out_enc1_art_m[0] = 125
        cs.circle.out_angle_m[0] = 340
        cs.circle.out_enc1_m[0]  = 40
        cs.circle.out_enc2_m[0]  = 900
        cs.circle.out_enc3_m[0]  = 80
        
        cs.circle.first_half_width_left_m[0] = 70  #左圆环，逆时针跑
        cs.circle.second_half_width_left_m[0] = 70

        cs.circle.first_half_width_right_m[0] = 65   #右圆环，顺时针跑
        cs.circle.second_half_width_right_m[0] = 70
        
        cs.circle.left_error_limit_m[0]  = -14#中圆环290
        cs.circle.right_error_limit_m[0] =  14#中圆环290
        
        
        #大圆环290
        cs.circle.line_left[0] = 10#大圆环290
        cs.circle.line_right[0] = 10#大圆环290
        
        cs.circle.out_enc1_art_l[0] = 125+cs.circle.big_enc[0]
        cs.circle.out_angle_l[0] = 360+cs.circle.big_angle[0]
        cs.circle.out_enc1_l[0]  = 40
        cs.circle.out_enc2_l[0]  = 1200
        cs.circle.out_enc3_l[0]  = 170
        
        cs.circle.first_half_width_left_l[0] =75
        cs.circle.second_half_width_left_l[0] = 75

        cs.circle.first_half_width_right_l[0] = 75   #右圆环，顺时针跑
        cs.circle.second_half_width_right_l[0] = 75
        #大圆环250
        cs.circle.left_error_limit_l[0] = -20#大圆环290
        cs.circle.right_error_limit_l[0] = 22#大圆环290
        
        
        
    elif(rank[0] == 5 and pid.start[0] == 0): #310
        
         #小圆环310
        cs.circle.line_left[0] = 10#小圆环310
        cs.circle.line_right[0] = 10#小圆环310
        
        cs.circle.out_enc1_art_s[0] = 97
        cs.circle.out_angle_s[0] = 350
        cs.circle.out_enc1_s[0]  = 35
        cs.circle.out_enc2_s[0]  = 900
        cs.circle.out_enc3_s[0]  = 70
        

        cs.circle.first_half_width_left_s[0] = 70  #左圆环，逆时针跑
        cs.circle.second_half_width_left_s[0] = 70

        cs.circle.first_half_width_right_s[0] = 68   #右圆环，顺时针跑
        cs.circle.second_half_width_right_s[0] = 70
        
        cs.circle.left_error_limit_s[0]  = -14#小圆环310
        cs.circle.right_error_limit_s[0] = 15.5#小圆环310
        
        
        #中圆环310
        cs.circle.line_left[0] = 10#中圆环310
        cs.circle.line_right[0] = 10#中圆环310
        
        cs.circle.out_enc1_art_m[0] = 125
        cs.circle.out_angle_m[0] = 340
        cs.circle.out_enc1_m[0]  = 40
        cs.circle.out_enc2_m[0]  = 900
        cs.circle.out_enc3_m[0]  = 80
        
        cs.circle.first_half_width_left_m[0] = 70  #左圆环，逆时针跑
        cs.circle.second_half_width_left_m[0] = 70

        cs.circle.first_half_width_right_m[0] = 65   #右圆环，顺时针跑
        cs.circle.second_half_width_right_m[0] = 70
        
        cs.circle.left_error_limit_m[0]  = -14#中圆环310
        cs.circle.right_error_limit_m[0] =  14#中圆环310
        
        
        
        #大圆环310
        cs.circle.line_left[0] = 10#大圆环310
        cs.circle.line_right[0] = 10#大圆环310
        
        cs.circle.out_enc1_art_l[0] = 125+cs.circle.big_enc[0]
        cs.circle.out_angle_l[0] = 360+cs.circle.big_angle[0]
        cs.circle.out_enc1_l[0]  = 40
        cs.circle.out_enc2_l[0]  = 1200
        cs.circle.out_enc3_l[0]  = 170
        
        cs.circle.first_half_width_left_l[0] =75
        cs.circle.second_half_width_left_l[0] = 75

        cs.circle.first_half_width_right_l[0] = 75   #右圆环，顺时针跑
        cs.circle.second_half_width_right_l[0] = 75
        #大圆环310
        cs.circle.left_error_limit_l[0] = -20#大圆环310
        cs.circle.right_error_limit_l[0] = 22#大圆环310
        

            

        
def circle_check_set():
    
    
    
    if(imu.data.temp_angle >= 4000-25):
        
        #圆环
        cs.line.width[0] = 44
        cs.circle.boundary_change[0] = 12
        cs.circle.c2_width_in_min[0] = 60
        cs.circle.c2_width_in_max[0] = 95
        
        #十字
        cs.cross.c1_width_in[0] = 44 + 25
        cs.cross.c1_width_out[0] = 44 + 10
        cs.cross.c2_width_in[0] =  75 + 10
        cs.cross.c2_width_out[0] = 33 + 15
        
        
        
        
    elif(imu.data.temp_angle >= 3950-25):
        
        #圆环
        cs.line.width[0] = 47
        cs.circle.boundary_change[0] = 12
        cs.circle.c2_width_in_min[0] = 60
        cs.circle.c2_width_in_max[0] = 95
        #十字
        cs.cross.c1_width_in[0] = 47 + 25
        cs.cross.c1_width_out[0] = 47 + 10
        cs.cross.c2_width_in[0] =  75 + 10
        cs.cross.c2_width_out[0] = 36 + 15
        
        
    elif(imu.data.temp_angle >= 3900-25):
        
        #圆环
        cs.line.width[0] = 52
        cs.circle.boundary_change[0] = 11
        cs.circle.c2_width_in_min[0] = 60
        cs.circle.c2_width_in_max[0] = 95
        #十字
        #十字
        cs.cross.c1_width_in[0] = 52 + 25
        cs.cross.c1_width_out[0] = 52 + 10
        cs.cross.c2_width_in[0] =  78 + 10
        cs.cross.c2_width_out[0] = 40 + 15
        
        
    elif(imu.data.temp_angle >= 3850-25):
        
        #圆环
        cs.line.width[0] = 55
        cs.circle.boundary_change[0] = 11
        cs.circle.c2_width_in_min[0] = 65
        cs.circle.c2_width_in_max[0] = 100
        #十字
        cs.cross.c1_width_in[0] = 55 + 25
        cs.cross.c1_width_out[0] = 55 + 10
        cs.cross.c2_width_in[0] =  79 + 10
        cs.cross.c2_width_out[0] = 43 + 15
        
        
    elif(imu.data.temp_angle >= 3800-25):
        
        #圆环
        cs.line.width[0] = 59
        cs.circle.boundary_change[0] = 10
        cs.circle.c2_width_in_min[0] = 70
        cs.circle.c2_width_in_max[0] = 100
        #十字
        cs.cross.c1_width_in[0] = 59 + 25
        cs.cross.c1_width_out[0] = 59 + 10
        cs.cross.c2_width_in[0] =  82 + 10
        cs.cross.c2_width_out[0] = 47 + 15
        
        
    elif(imu.data.temp_angle >= 3750-25):
        
        #圆环
        cs.line.width[0] = 63
        cs.circle.boundary_change[0] = 10
        cs.circle.c2_width_in_min[0] = 70
        cs.circle.c2_width_in_max[0] = 100
        #十字
        cs.cross.c1_width_in[0] = 63 + 25
        cs.cross.c1_width_out[0] = 63 + 10
        cs.cross.c2_width_in[0] =  82 + 10
        cs.cross.c2_width_out[0] = 49 + 15
        
        
    elif(imu.data.temp_angle >= 3700-25):
        
        #圆环
        cs.line.width[0] = 65
        cs.circle.boundary_change[0] = 9
        cs.circle.c2_width_in_min[0] = 70
        cs.circle.c2_width_in_max[0] = 100
        #十字
        cs.cross.c1_width_in[0] = 65 + 25
        cs.cross.c1_width_out[0] = 65 + 10
        cs.cross.c2_width_in[0] =  84 + 10
        cs.cross.c2_width_out[0] = 56 + 15
        
        
        
    elif(imu.data.temp_angle >= 3650-25):
        
        #圆环
        cs.line.width[0] = 69
        cs.circle.boundary_change[0] = 8
        cs.circle.c2_width_in_min[0] = 70
        cs.circle.c2_width_in_max[0] = 100
        #十字
        cs.cross.c1_width_in[0] = 69 + 25
        cs.cross.c1_width_out[0] = 69 + 10
        cs.cross.c2_width_in[0] =  84 + 10
        cs.cross.c2_width_out[0] = 56 + 15
        
        
        
    elif(imu.data.temp_angle >= 3600-25):
        
        
        
        #圆环
        cs.line.width[0] = 72
        cs.circle.boundary_change[0] = 7
        cs.circle.c2_width_in_min[0] = 72
        cs.circle.c2_width_in_max[0] = 105
        #十字
        cs.cross.c1_width_in[0] = 72 + 25
        cs.cross.c1_width_out[0] = 72 + 10
        cs.cross.c2_width_in[0] =  86 + 10
        cs.cross.c2_width_out[0] = 58 + 15
        
        
        
    elif(imu.data.temp_angle >= 3550-25):
        
        
        
        #圆环
        cs.line.width[0] = 76
        cs.circle.boundary_change[0] = 6
        cs.circle.c2_width_in_min[0] = 72
        cs.circle.c2_width_in_max[0] = 105
        #十字
        cs.cross.c1_width_in[0] = 76 + 25
        cs.cross.c1_width_out[0] = 76 + 10
        cs.cross.c2_width_in[0] =  88 + 10
        cs.cross.c2_width_out[0] = 62 + 15
        
        
        
        


def param():
    global rank, target_speed, kp, kp2, kd, kd2
    
    if(pid.start[0] == 2 or pid.start[0] == -1):
        
        if rank[0] == 1: #  第一档速度生效
    
            real_speed = (pid.enc1_data + pid.enc2_data) / 2 #计算当前速度
        
            rate = real_speed / (target_speed[0]+1)           #当前速度与期望速度的比值，范围 %0 到 %100
            if(rate > 1):
                rate = 1
    
            pid.kp[0] =  (0.5 + 0.5* rate)*kp[0]              #越接近期望速度，转向环参数就越接近我们设定的值
            pid.kp2[0] = (0.5 + 0.5* rate)*kp2[0]
            pid.kd2[0] = (0.5 + 0.5* rate)*kd2[0]
            
            
        elif rank[0] == 2:
            pass
        elif rank[0] == 3:
            pass
        