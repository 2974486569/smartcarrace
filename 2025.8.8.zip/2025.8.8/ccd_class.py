


class Flag:
    def __init__(self):
        self.road_type = [0]
        self.error = [0]
        self.error1 = [0]
        self.check = [0]
        

        
    def reset(self):
        self.road_type[0] = 0
        self.error[0] = 0
        
        self.check[0] = 0
class Line:
    def __init__(self):
        
        self.enable = [0]
        
        self.threshold = [3]
        self.c1_threshold = [5]
        self.gz_threshold = [85]
        self.width = [56]
        
    def reset(self):
        self.enable[0] = 0
        
        self.threshold[0] = 3
        self.c1_threshold[0] = 5
        self.gz_threshold[0] = 85

        
class Cross:
    def __init__(self):
        self.flag = [0]
        
        self.check_flag = 0
        self.check_time = 0
        
        self.enable = [0]
        
        self.c1_width_in = [72]
        self.c1_width_out = [70]
        self.c2_width_in = [85]
        self.c2_width_out = [50]
        
        self.num = [0]
        
        self.encoder_sum = [0]
        self.encoder_sum_global = [0]
        
    def reset(self):
        
        self.flag[0] = 0
        
        self.check_flag = 0
        self.check_time = 0
        
        self.enable[0] = 0
                
        self.num[0] = 0
        
        self.encoder_sum[0] = 0
        self.encoder_sum_global[0] = 0
        
class Circle:
    def __init__(self):
        
        self.ccd_out_flag = [0]
        
        self.ccd_out1 = [7]
        self.ccd_out2 = [4]

        self.big_enc = [20]
        self.big_angle = [15]
        
        self.stop = [0]
        self.stop_enc = [0]
        
        self.line_left= [0]
        self.line_right = [0]
        
        
        self.flag = [0]
        
        self.judge = [0]
        
        self.blob_num = [1]
        self.blob = [3]  #1是左圆环，2是右圆环，3是坡道
        self.blob1 = [3]
        self.blob2 = [3]
        self.blob3 = [3]
        self.blob4 = [3]
        self.blob5 = [3]
        self.blob6 = [3]
        
        self.num = [1]
        self.type = [0]
        self.type1 = [3]
        self.type2 = [3]
        self.type3 = [3]
        self.type4 = [3]
        
        #self.c1_width_in = [60]
        self.c1_width_out = [55]
        self.c2_width_in_max = [100]
        self.c2_width_in_min = [60]
        
        self.c1_cross_or_circle = [0]
        self.c2_cross_or_circle = [0]
        
        self.boundary_change = [0]  #c1突变值判断
        
        self.out_angle = [0]     #陀螺仪判断是否出环

        self.out_enc1 = [0]#编码器判断是否出
        self.out_enc2 = [0]#编码器判断是否出
        self.out_enc3 = [0]#编码器判断是否出
        
        self.left_error_limit = [0]
        self.right_error_limit = [0]
        
        self.first_half_width = [0]    #前半段补线
        self.second_half_width = [0]   #后半段补线
        
        self.out_enc1_art = [0]#编码器判断是否出   160速度
        
        self.out_enc1_art_s = [0]#编码器判断是否出   160速度
        self.out_enc1_art_m = [0]#编码器判断是否出   200速度
        self.out_enc1_art_l = [0]#编码器判断是否出  250速度
      
        #小圆环
        self.out_angle_s = [360]
        
        self.out_enc1_s = [40]#编码器判断是否出
        self.out_enc2_s = [540]#编码器判断是否出
        self.out_enc3_s = [100]#编码器判断是否出
        
        self.left_error_limit_s = [-6]
        self.right_error_limit_s = [6]
        
        self.first_half_width_left_s = [60]    #前半段补线
        self.second_half_width_left_s = [50]   #后半段补线

        self.first_half_width_right_s = [60]    #前半段补线
        self.second_half_width_right_s = [50]   #后半段补线
        
        
        #中圆环
        self.out_angle_m = [360]
        
        self.out_enc1_m = [40]#编码器判断是否出
        self.out_enc2_m = [540]#编码器判断是否出
        self.out_enc3_m = [100]#编码器判断是否出
        
        self.left_error_limit_m = [-4]
        self.right_error_limit_m = [4]
        
        self.first_half_width_left_m = [60]    #前半段补线
        self.second_half_width_left_m = [50]   #后半段补线

        self.first_half_width_right_m = [60]    #前半段补线
        self.second_half_width_right_m = [50]   #后半段补线
        
        #大圆环
        self.out_angle_l = [360]
        
        self.out_enc1_l = [40]#编码器判断是否出
        self.out_enc2_l = [540]#编码器判断是否出
        self.out_enc3_l = [100]#编码器判断是否出
        
        self.left_error_limit_l = [-3]
        self.right_error_limit_l = [3]
        
        self.first_half_width_left_l = [60]    #前半段补线
        self.second_half_width_left_l = [50]   #后半段补线

        self.first_half_width_right_l = [60]    #前半段补线
        self.second_half_width_right_l = [50]   #后半段补线
    

        
        self.set_width = [0]           #赛道宽度，补线用
        self.virtual_middle = [0]      #补线后的新中线
        self.angle = [0]               #进入圆环前的角度值
        
        self.encoder_sum = [0]

        self.enable = [0]
        
    def reset(self):
        self.flag[0] = 0
        self.ccd_out_flag[0] = 0
        
        
        self.num[0] = 1
        self.type[0] = 0
        
        self.blob_num[0] = 1
        self.blob[0] = 0
        
        
#         self.out_angle_sd[0] = 360 #陀螺仪判断是否出环  shadow备用
#         self.out_angle[0] = self.out_angle_sd[0]     #陀螺仪判断是否出环
#         self.out_angle_diff[0] = 25     #大小圆环判断的差值
      
        self.set_width[0] = 0           #赛道宽度，补线用
        self.virtual_middle[0] = 0      #补线后的新中线
        self.angle[0] = 0               #进入圆环前的角度值
        
        self.encoder_sum[0] = 0
        
        self.enable[0] = 0

        
class Box:
    def __init__(self):
        self.flag = [0]
        self.encoder_sum = [0]
        self.middle = [0]
        self.threshold = [7]
        self.set_width = [11]
        
    def reset(self):
        self.__init__()
        
        
class Ramp:
    def __init__(self):
        self.flag = [0]
        self.distance = [0]
        self.encoder_sum = [0]
        self.encoder_sum_global = [0]
        self.threshold = [110]
        
    def reset(self):
        self.__init__()

        
class Stop:
    def __init__(self):
        
        self.enc = [0]
        self.threshold_rate = [0.6]
        self.num_bright = [0]
        self.num_low = [0]
        self.enable = [0]
        
    def reset(self):
        self.enc[0] = 0
        self.num_bright[0] = 0
        self.num_low[0] = 0
        self.enable[0] = 0
        
class Out:
    def __init__(self):
        
        self.max = [0]
        self.threshold = [0.01]
        
    def reset(self):
        self.__init__()

        
        
        
flag = Flag()
line = Line()
cross = Cross()
circle = Circle()
box = Box()
ramp = Ramp()
stop = Stop()
out = Out()
       
